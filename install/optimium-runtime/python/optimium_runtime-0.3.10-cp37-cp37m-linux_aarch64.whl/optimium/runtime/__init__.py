"""Entrypoint of optimium.runtime"""

# pylint: disable=wildcard-import
from optimium.runtime._runtime import *  # noqa
