//===-- Shape.h - Represents shape of the tensor ----------------*- C++ -*-===//
//
// This file is part of Optimium-Runtime. Confidential and proprietary.
//
// Copyright (c) ENERZAi Corporation.
// All Rights Reserved.
//
//===----------------------------------------------------------------------===//
///
/// \file This file contains definition of \c Shape class.
///
//===----------------------------------------------------------------------===//
#ifndef OPTIMIUM_RUNTIME_SHAPE_H
#define OPTIMIUM_RUNTIME_SHAPE_H

#include "Optimium/Runtime/Export.h"
#include "Optimium/Runtime/Utils/NonCopyable.h"

#include <algorithm>
#include <array>
#include <cassert>
#include <cstdint>
#include <string>
#include <type_traits>
#include <vector>

namespace optimium::runtime {
/// Represents a shape of the tensor.
class OPTIMIUM_RT_API Shape final {
public:
  OPTIMIUM_RT_DEFAULT_COPYABLE(Shape)
  OPTIMIUM_RT_DEFAULT_MOVABLE(Shape)

  static constexpr size_t kMaxDimensions = 8;

  using ShapeT = uint32_t;

  using value_type = ShapeT;
  using const_iterator = std::array<ShapeT, kMaxDimensions>::const_iterator;

  Shape() = default;

  /// Construct \c Shape from integers.
  /// \tparam Ints Variadic type list of integers.
  ///              Should be convertible to \c ShapeT.
  /// \param Dimensions List of integers that represent dimension.
  template <typename... Ints>
  explicit Shape(Ints... Dimensions)
      : DimensionSize(static_cast<ShapeT>(sizeof...(Ints))),
        Dimensions({Dimensions...}) {
    static_assert(sizeof...(Ints) <= kMaxDimensions,
                  "Dimensions exceeds maximum length: 8");
    checkDims();
  }

  /// Construct \c Shape from iterator.
  /// \tparam IterT iterable type that has \c value_type convertible
  ///               to \c ShapeT.
  /// \param Begin an iterator that points start position in the container.
  /// \param End an iterator that points end position in the container.
  template <typename IterT>
  Shape(IterT Begin, IterT End) {
    auto Length = std::distance(Begin, End);
    assert((Length >= 0 && Length <= kMaxDimensions) && "out of range");

    DimensionSize = Length;
    std::copy(Begin, End, Dimensions.begin());
    checkDims();
  }

  /// Get total count of elements.
  /// \return an integer that represents total count of elements.
  [[nodiscard]] size_t getTotalElementCount() const;

  /// Get count of element in given dimension index.
  /// \param Index index of dimensions to get count.
  /// \return an integer that represents count of elements in the index.
  [[nodiscard]] ShapeT getElementCountAt(size_t Index) const {
    assert(Index < DimensionSize && "out of range");
    return Dimensions[Index];
  }

  /// Get stride of given dimension index.
  /// \param Index index of dimensions to get stride.
  /// \return an integer that represents stride from the index.
  [[nodiscard]] size_t getStride(size_t Index) const;

  /// Get strides of all dimensions.
  /// \return a vector of integers that represents strides of each dimensions.
  [[nodiscard]] std::vector<size_t> getStrides() const;

  /// Get count of elements in given dimension index.
  /// \see Shape::getElementCountAt()
  ShapeT operator[](size_t Index) const { return getElementCountAt(Index); }

  /// Get size of dimensions.
  /// \return an integer that represents size of dimensions.
  [[nodiscard]] ShapeT getDimensionSize() const { return DimensionSize; }

  /// Check the shape is empty(dimensions is zero).
  /// \return \c true if empty, otherwise \c false.
  [[nodiscard]] bool empty() const { return DimensionSize == 0; }

  /// Check the shape is same with \c Other.
  /// \param Other another \c Shape to compare.
  /// \return \c true if shapes are same, otherwise \c false.
  [[nodiscard]] bool equals(const Shape &Other) const;

  [[nodiscard]] const_iterator begin() const { return Dimensions.begin(); }

  [[nodiscard]] const_iterator end() const { return begin() + DimensionSize; }

  [[nodiscard]] ShapeT front() const { return Dimensions[0]; }

  [[nodiscard]] ShapeT back() const { return Dimensions[DimensionSize - 1]; }

  bool operator==(const Shape &Other) const { return equals(Other); }

  bool operator!=(const Shape &Other) const { return !equals(Other); }

  [[nodiscard]] std::string toString() const;

private:
  std::array<ShapeT, kMaxDimensions> Dimensions = {};
  ShapeT DimensionSize = 0;

  void checkDims() {
    auto End = Dimensions.begin() + DimensionSize;
    auto It = std::find(Dimensions.begin(), End, ShapeT(0));
    assert(It == End && "cannot be zero in dimension.");
  }
}; // end class Shape
} // end namespace optimium::runtime

#endif // OPTIMIUM_RUNTIME_SHAPE_H