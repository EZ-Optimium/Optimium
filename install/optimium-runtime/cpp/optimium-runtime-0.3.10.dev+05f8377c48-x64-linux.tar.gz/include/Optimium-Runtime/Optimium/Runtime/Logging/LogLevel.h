//===-- LogLevel.h - Severity of the message --------------------*- C++ -*-===//
//
// This file is part of Optimium-Runtime. Confidential and proprietary.
//
// Copyright (c) 2022~2023 ENERZAi Corporation.
// All Rights Reserved.
//
//===----------------------------------------------------------------------===//
///
/// \file
/// This file contains definition of \c LogLevel enum.
///
//===----------------------------------------------------------------------===//
#ifndef OPTIMIUM_RUNTIME_LOGGING_LOGLEVEL_H
#define OPTIMIUM_RUNTIME_LOGGING_LOGLEVEL_H

#include "Optimium/Runtime/Export.h"

#include <string_view>

namespace optimium::runtime {
// clang-format off
#define OPTIMIUM_RT_LOGLEVEL_ENUM(Op) \
  Op(Debug) \
  Op(Verbose) \
  Op(Info) \
  Op(Warning) \
  Op(Error)
// clang-format on

/// Represents severity of the message.
enum class LogLevel {
/// \var LogLevel::Debug
///      Level for verbose, informative message for debugging.
/// \var LogLevel::Verbose
///      Level for verbose information.
/// \var LogLevel::Info
///      Level for brief information.
/// \var LogLevel::Warning
///      Level for errors which are not so severe and recoverable.
/// \var LogLevel::Error
///      Level for fatal and severe errors.

#define OP(Value) Value,
  OPTIMIUM_RT_LOGLEVEL_ENUM(OP)
#undef OP
}; // end enum LogLevel

/// Convert \c LogLevel to readable string.
/// \param Value value for convert to string.
/// \return a string that represents corresponding \c LogLevel.
OPTIMIUM_RT_API std::string_view toString(LogLevel Value);
} // end namespace optimium::runtime

#endif // OPTIMIUM_RUNTIME_LOGGING_LOGLEVEL_H