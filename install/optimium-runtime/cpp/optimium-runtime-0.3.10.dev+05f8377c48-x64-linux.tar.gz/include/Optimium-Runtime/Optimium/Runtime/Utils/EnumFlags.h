//===-- EnumFlags.h - Set of enumeration values -----------------*- C++ -*-===//
//
// This file is part of Optimium-Runtime. Confidential and proprietary.
//
// Copyright (c) 2022~2023 ENERZAi Corporation.
// All Rights Reserved.
//
//===----------------------------------------------------------------------===//
///
/// \file
/// This file contains \c EnumFlags struct that represents a set of
/// enumeration values(flags).
///
//===----------------------------------------------------------------------===//
#ifndef OPTIMIUM_RUNTIME_UTILS_ENUM_FLAGS_H
#define OPTIMIUM_RUNTIME_UTILS_ENUM_FLAGS_H

#include "Optimium/Runtime/Assert.h"

#include <cstddef>
#include <cstdint>
#include <iterator>
#include <type_traits>

namespace optimium::runtime {
/// Implements a set of enumeration values into bitfield (a.k.a flags)
/// Direct instantiation of this class is not allowed.
/// \tparam EnumT an enumeration type to represent flags.
///               \c EnumT should be an enumeration type.
/// \tparam BitfieldT basis type to store bits. the type should be large
///                   enough to contain ALL enumeration values.
///                   \c BitfieldT should be unsigned integral type.
///                   Default to \c uint64_t.
/// \tparam Last constant value that represents maximum value of enumeration
///              type. Default to \c EnumT::Last.
template <typename EnumT, typename BitfieldT = uint64_t,
          EnumT Last = EnumT::Last>
struct EnumFlags {
  static constexpr auto kMaxBits = static_cast<size_t>(Last) + 1;
  static constexpr auto k0 = BitfieldT(0);
  static constexpr auto k1 = BitfieldT(1);

  static_assert(std::is_enum_v<EnumT>);
  static_assert(std::is_unsigned_v<BitfieldT>,
                "BitfieldT should be unsigned integral type.");
  static_assert(sizeof(BitfieldT) * 8 > kMaxBits,
                "EnumT does not fit in BitfieldT");

private:
  BitfieldT Flags{};

public:
  EnumFlags() = default;

  /// Test the flag is set.
  /// \param V a flag to test.
  /// \return \c true if the flag is set, otherwise \c false.
  [[nodiscard]] bool hasFlag(EnumT V) const {
    assert((V <= Last) && "value is grater than known maximum value.");
    return (Flags & (k1 << static_cast<BitfieldT>(V))) != k0;
  }

  /// Test flags are set.
  /// \param V an \c EnumFlags to test.
  /// \return \c true if flags are set, otherwise \c false.
  [[nodiscard]] bool hasFlags(const EnumFlags &V) const {
    return (Flags & V.Flags) == V.Flags;
  }

  /// Test flags are set.
  /// \tparam ContainerT type of container that contains flags.
  /// \param Container any container that contains flags to test.
  /// \return \c true if flags are set, otherwise \c false.
  template <typename ContainerT>
  [[nodiscard]] bool hasFlags(const ContainerT &Container) const {
    auto F = k0;
    auto Begin = std::begin(Container);
    auto End = std::end(Container);

    for (auto It = Begin; It != End; ++It) {
      assert((static_cast<BitfieldT>(*It) < kMaxBits) &&
             "value is grater than known maximum value.");

      F |= (k1 << static_cast<BitfieldT>(*It));
    }

    return (Flags & F) == F;
  }

  /// Set the flag.
  /// \param V a flag to set.
  void setFlag(EnumT V) {
    assert((V <= Last) && "value is grater than known maximum value.");
    Flags |= (k1 << static_cast<BitfieldT>(V));
  }

  /// Set flags.
  /// \tparam ContainerT type of container that contains flags.
  /// \param Container any container that contains flags to set.
  template <typename ContainerT>
  void setFlags(const ContainerT &Container) {
    auto Begin = std::begin(Container);
    auto End = std::end(Container);

    for (auto It = Begin; It != End; ++It) {
      assert((static_cast<BitfieldT>(*It) < kMaxBits) &&
             "value is grater than known maximum value.");
      Flags |= (k1 << static_cast<BitfieldT>(*It));
    }
  }

  struct const_iterator {
    BitfieldT Flags;
    int Cursor = 0;

    const_iterator(BitfieldT Flags, int Cursor) : Flags(Flags), Cursor(Cursor) {
      // if cursor`th bit is zero, find next one.
      if ((k1 << Cursor) == k0)
        next();
    }

    void next() {
      while (Cursor < kMaxBits) {
        ++Cursor;
        if (((k1 << Cursor) & Flags) != k0)
          break;
      }
    }

    const_iterator &operator++() {
      next();
      return *this;
    }

    const_iterator operator++(int) {
      auto It = *this;
      next();
      return It;
    }

    EnumT operator*() const {
      assert(Cursor != kMaxBits);
      return static_cast<EnumT>(Cursor);
    }

    bool operator==(const const_iterator &Other) const {
      assert(Flags == Other.Flags);
      return Cursor == Other.Cursor;
    }

    bool operator!=(const const_iterator &Other) const {
      return !(operator==(Other));
    }
  }; // end struct const_iterator

  const_iterator begin() const { return const_iterator(Flags, 0); }
  const_iterator end() const { return const_iterator{Flags, kMaxBits}; }

  /// Set flags.
  /// \param InitList list of flags.
  void setFlags(std::initializer_list<EnumT> InitList) { setFlags<>(InitList); }

  /// Clear the flag.
  /// \param V a flag to clear.
  void clearFlag(EnumT V) {
    assert((V <= Last) && "value is grater than known maximum value.");
    Flags &= ~(k1 << static_cast<BitfieldT>(V));
  }

  /// Get raw value.
  /// \return an integral value that represents set of flags.
  [[nodiscard]] BitfieldT getFlags() const { return Flags; }

  void setFlags(BitfieldT Value) { Flags = Value; }

  /// Deserialize bitfields into sequence of flags.
  /// \tparam ContainerT type of container that contains flags.
  /// \tparam OtherEnumT any enumeration type to convert. Default is \c EnumT.
  /// \param Container any container to store flags.
  /// \warning if \c OtherEnumT != \c EnumT, the user have responsibility of
  ///          unintended bug due to implicit conversion between types.
  template <typename ContainerT, typename OtherEnumT = EnumT>
  void unpack(ContainerT &Container) const {
    for (auto i = 0; i < kMaxBits; ++i)
      if ((Flags & (k1 << i)) != k0)
        Container.insert(Container.end(), static_cast<OtherEnumT>(i));
  }
}; // end class EnumFlags<EnumT, BitfieldT>
} // end namespace optimium::runtime

#endif // OPTIMIUM_RUNTIME_UTILS_ENUM_FLAGS_H