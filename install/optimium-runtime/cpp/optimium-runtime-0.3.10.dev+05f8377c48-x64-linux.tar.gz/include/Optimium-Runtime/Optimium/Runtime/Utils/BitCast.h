//===-- BitCast.h - backport of std::bit_cast in C++20 ----------*- C++ -*-===//
//
// This file is part of Optimium-Runtime. Confidential and proprietary.
//
// Copyright (c) 2022~2023 ENERZAi Corporation.
// All Rights Reserved.
//
//===----------------------------------------------------------------------===//
///
/// \file
/// This file contains implementation of \c bit_cast which is same as
/// \c std::bit_cast in C++20
///
//===----------------------------------------------------------------------===//
#ifndef OPTIMIUM_RUNTIME_UTILS_BIT_CAST_H
#define OPTIMIUM_RUNTIME_UTILS_BIT_CAST_H

#include <type_traits>

#ifndef __has_builtin
#define __has_builtin(x) (0)
#endif

namespace optimium::runtime {
template <typename DestT, typename SourceT>
/// Cast value from \c SourceT to \c DestT as-is.
/// \tparam DestT destination type to cast.
/// \tparam SourceT source type to cast from.
/// \param Source a value to be casted.
/// \return bitwise casted \c Source into \c DestT.
constexpr DestT bit_cast(const SourceT &Source) {
  static_assert(sizeof(DestT) == sizeof(SourceT),
                "sizeof(DestT) != sizeof(SourceT)");
  static_assert(std::is_trivially_copyable_v<SourceT>,
                "SourceT must be trivially copyable.");
  static_assert(std::is_trivially_copyable_v<DestT>,
                "DestT must be trivially copyable.");

#if __has_builtin(__builtin_bit_cast)
  return __builtin_bit_cast(DestT, Source);
#elif __has_builtin(__builtin_memcpy)
  DestT Dest;
  __builtin_memcpy(&Dest, &Source, sizeof(DestT));
  return Dest;
#else
  return DestT(*reinterpret_cast<const DestT *>(&Source));
#endif
}
} // namespace optimium::runtime

#endif // OPTIMIUM_RUNTIME_UTILS_BIT_CAST_H