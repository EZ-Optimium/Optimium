//===-- Host.h - Provide host information -----------------------*- C++ -*-===//
//
// This file is part of Optimium-Runtime. Confidential and proprietary.
//
// Copyright (c) 2022~2023 ENERZAi Corporation.
// All Rights Reserved.
//
//===----------------------------------------------------------------------===//
///
/// \file
/// This file contains definitions of struct and enumerations that describe
/// information of host machine.
///
//===----------------------------------------------------------------------===//
#ifndef OPTIMIUM_RUNTIME_HOST_H
#define OPTIMIUM_RUNTIME_HOST_H

#include "Optimium/Runtime/Export.h"

#include <string>
#include <string_view>

namespace optimium::runtime {
enum class DeviceKind;

// clang-format off
#define OPTIMIUM_RT_CONNECTION_METHOD_ENUM(Op) \
  Op(Local) \
  Op(SSH) \
  Op(Direct)
// clang-format on

/// Represents connection method to the host.
enum class ConnectionMethod {
/// \var ConnectionMethod::Local
///      Localhost.
/// \var ConnectionMethod::SSH
///      Connected via SSH tunneling.
/// \var ConnectionMethod::Direct
///      Connected via direct TCP/IP connection.

#define OP(Value) Value,
  OPTIMIUM_RT_CONNECTION_METHOD_ENUM(OP)
#undef OP
      Last = Direct
}; // end enum ConnectionMethod

/// Convert \c ConnectionMethod to readable string.
/// \param Value value for convert to string.
/// \return a string that represents corresponding \c ConnectionMethod.
OPTIMIUM_RT_API std::string_view toString(ConnectionMethod Value);

/// Represents information of a host that devices are connected.
struct HostInfo {
  /// Represents a way how the context connected with the host.
  ConnectionMethod Method;

  /// Represents a architecture of the host. This always satisfy
  /// \c isDeviceCPU().
  DeviceKind Architecture;

  /// Represents a address of the host.
  std::string_view Address;

  /// Convert \c HostInfo to readable string.
  /// \return a string that represents corresponding \c HostInfo.
  OPTIMIUM_RT_API std::string toString() const;
}; // end struct HostInfo
} // end namespace optimium::runtime

#endif // OPTIMIUM_RUNTIME_HOST_H