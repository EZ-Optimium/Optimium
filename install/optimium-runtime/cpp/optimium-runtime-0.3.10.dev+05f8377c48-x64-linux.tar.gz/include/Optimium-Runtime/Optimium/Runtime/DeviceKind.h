//===-- DeviceKind.h - Represents kind of the device ------------*- C++ -*-===//
//
// This file is part of Optimium-Runtime. Confidential and proprietary.
//
// Copyright (c) 2022~2023 ENERZAi Corporation.
// All Rights Reserved.
//
//===----------------------------------------------------------------------===//
///
/// \file
/// This file contains definitions of \c DeviceKind enumeration that
/// represents kind of the device.
///
//===----------------------------------------------------------------------===//
#ifndef OPTIMIUM_RUNTIME_DEVICE_KIND_H
#define OPTIMIUM_RUNTIME_DEVICE_KIND_H

#include "Optimium/Runtime/Export.h"

#include <cassert>
#include <string_view>

namespace optimium::runtime {
// clang-format off
#define OPTIMIUM_RT_DEVICE_KIND_ENUM(Op) \
  Op(Unspecified) \
  Op(Neutral) \
  Op(x86) \
  Op(x64) \
  Op(ARM) \
  Op(ARM64) \
  Op(AnyCPU) \
  Op(NVIDIA) \
  Op(AMDGPU) \
  Op(IntelGPU) \
  Op(Mali) \
  Op(Adreno) \
  Op(AnyGPU) \
  Op(Hexagon) \
  Op(Myriad) \
  Op(ARA1) \
  Op(EdgeTPU) \
  Op(CV22) \
  Op(AnyNPU)
// clang-format on

/// Represents kind of devices that supports and recognized on runtime.
/// \warning Must be synced with Device.proto.
enum class DeviceKind {
/// \var DeviceKind::Unspecified
///      Unspecified/invalid device.
/// \var DeviceKind::Neutral
///      Device agnostic kind
/// \var DeviceKind::x86
///      Represents Intel x86 CPU.
/// \var DeviceKind::x64
///      Represents AMD64 (Intel IA-32e, x86_64, etc) CPU.
/// \var DeviceKind::ARM
///      Represents ARM 32bit(ARM v7-A) CPU.
/// \var DeviceKind::ARM64
///      Represents ARM 64bit (aarch64, ARM v8/v9) CPU.
/// \var DeviceKind::AnyCPU
///      Represents any device grouped in CPU.
/// \var DeviceKind::NVIDIA
///      Represents NVidia GPU.
/// \var DeviceKind::AMDGPU
///      Represents AMD Radeon GPU.
/// \var DeviceKind::IntelGPU
///      Represents Intel (Intel UHD, Intel iris, etc) GPU.
/// \var DeviceKind::Mali
///      Represents ARM Mail GPU.
/// \var DeviceKind::Adreno
///      Represents Snapdragon Adreno GPU.
/// \var DeviceKind::AnyGPU
///      Represents any device grouped in GPU.
/// \var DeviceKind::Hexagon
///      Represents Snapdragon Hexagon NPU.
/// \var DeviceKind::Myriad
///      Represents Intel Movidius Myriad series NPU.
/// \var DeviceKind::ARA1
///      Represents Kinara ARA-1 NPU.
/// \var DeviceKind::EdgeTPU
///      Represents Coral EdgeTPU NPU.
/// \var DeviceKind::CV22
///      Represents Ambarella CV22 series NPU.
/// \var DeviceKind::AnyNPU
///      Represents any device grouped in NPU.

#define OP(Value) Value,
  OPTIMIUM_RT_DEVICE_KIND_ENUM(OP)
#undef OP
      Last = AnyNPU
}; // end enum DeviceKind

/// Check given \c DeviceKind is device-agnostic type.
/// \param Kind a \c DeviceKind to check.
/// \return \c true if the value is \c DeviceKind::Neutral, otherwise \c false.
constexpr bool isDeviceNeutral(DeviceKind Kind) noexcept {
  return Kind == DeviceKind::Neutral;
}

constexpr auto kDeviceKindCPUBegin = DeviceKind::x86;
constexpr auto kDeviceKindCPUEnd = DeviceKind::AnyCPU;

/// Check given \c DeviceKind is CPU device.
/// \param Kind a \c DeviceKind to check.
/// \return \c true if the value represents CPU, otherwise \c false.
constexpr bool isDeviceCPU(DeviceKind Kind) noexcept {
  return (kDeviceKindCPUBegin <= Kind) && (Kind <= kDeviceKindCPUEnd);
}

constexpr auto kDeviceKindGPUBegin = DeviceKind::NVIDIA;
constexpr auto kDeviceKindGPUEnd = DeviceKind::AnyGPU;

/// Check given \c DeviceKind is GPU device.
/// \param Kind a \c DeviceKind to check.
/// \return \c true if the value represents GPU, otherwise \c false.
constexpr bool isDeviceGPU(DeviceKind Kind) noexcept {
  return (kDeviceKindGPUBegin <= Kind) && (Kind <= kDeviceKindGPUEnd);
}

constexpr auto kDeviceKindNPUBegin = DeviceKind::Hexagon;
constexpr auto kDeviceKindNPUEnd = DeviceKind::AnyNPU;

/// Check given \c DeviceKind is NPU device.
/// \param Kind a \c DeviceKind to check.
/// \return \c true if the value represents NPU, otherwise \c false.
constexpr bool isDeviceNPU(DeviceKind Kind) noexcept {
  return (kDeviceKindNPUBegin <= Kind) && (Kind <= kDeviceKindNPUEnd);
}

/// Check given \c DeviceKind is capable for \c Target.
/// \param Kind
/// \param Target
/// \return \c true if \c Kind is capable for \c Target, otherwise \c false.
constexpr bool isKindCapable(DeviceKind Kind, DeviceKind Target) noexcept {
  assert(Kind != DeviceKind::Unspecified && Target != DeviceKind::Unspecified);

  switch (Kind) {
  case DeviceKind::Neutral:
    // ALL device kinds are allowed.
    return true;

  case DeviceKind::AnyCPU:
    return isDeviceCPU(Target);

  case DeviceKind::AnyGPU:
    return isDeviceGPU(Target);

  case DeviceKind::AnyNPU:
    return isDeviceNPU(Target);

  default:
    return (Kind == Target);
  }
}

/// Convert \c DeviceKind to readable string.
/// \param Value value for convert to string.
/// \return a string that represents corresponding \c DeviceKind.
OPTIMIUM_RT_API std::string_view toString(DeviceKind Value);
} // end namespace optimium::runtime

#endif // OPTIMIUM_RUNTIME_DEVICE_KIND_H