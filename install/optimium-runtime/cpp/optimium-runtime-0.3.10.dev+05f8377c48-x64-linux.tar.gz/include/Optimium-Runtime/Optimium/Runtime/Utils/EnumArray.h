//===-- EnumArray.h - Array with enum keys ----------------------*- C++ -*-===//
//
// This file is part of Optimium-Runtime. Confidential and proprietary.
//
// Copyright (c) 2022~2023 ENERZAi Corporation.
// All Rights Reserved.
//
//===----------------------------------------------------------------------===//
///
/// \file
/// This file contains declaration of \c EnumArray which is associative array
/// with keys of enumeration type.
/// This has same functionality with LLVM's \c EnumeratedArray but more
/// range-based for loop friendly.
///
//===----------------------------------------------------------------------===//
#ifndef OPTIMIUM_RUNTIME_UTILS_ENUM_ARRAY_H
#define OPTIMIUM_RUNTIME_UTILS_ENUM_ARRAY_H

#include <cassert>
#include <initializer_list>
#include <memory>

namespace optimium::runtime {
/// Associative array with keys of enumeration type.
/// \tparam EnumT enumeration type for the key.
/// \tparam ValueT type of value to be associated with the key.
/// \tparam Last enumeration value that represents end of key.
///              Defaults to \c EnumT::Last.
template <typename EnumT, typename ValueT, EnumT Last = EnumT::Last>
class EnumArray {
private:
  static constexpr auto kArrayLength = static_cast<size_t>(Last) + 1;
  ValueT Data[kArrayLength];

public:
  using iterator = ValueT *;
  using const_iterator = const ValueT *;

  using reference = ValueT &;
  using const_reference = const ValueT &;

  struct paired_iterator {
    EnumArray &Self;
    size_t Index;

    using value_type = std::pair<EnumT, reference>;

    value_type operator*() {
      return {static_cast<EnumT>(Index), Self.Data[Index]};
    }

    paired_iterator &operator++() {
      ++Index;
      return *this;
    }

    paired_iterator operator++(int) {
      auto Out = *this;
      ++Index;
      return Out;
    }

    bool operator==(const paired_iterator &Other) const {
      assert((&Self == &(Other.Self)) && "different owner.");
      return Index == Other.Index;
    }

    bool operator!=(const paired_iterator &Other) const {
      return !(operator==(Other));
    }
  }; // end struct paired_iterator

  constexpr EnumArray() = default;

  ///
  /// \param Init
  explicit EnumArray(ValueT &&Init) {
    std::uninitialized_fill(std::begin(Data), std::end(Data), Init);
  }

  ///
  /// \param Init
  EnumArray(std::initializer_list<ValueT> Init) {
    assert((Init.size() <= kArrayLength) && "initializer_list out of bound.");
    std::uninitialized_copy(Init.begin(), Init.end(), std::begin(Data));
  }

  constexpr iterator begin() { return Data; }
  constexpr iterator end() { return Data + kArrayLength; }

  constexpr const_iterator begin() const { return Data; }
  constexpr const_iterator end() const { return Data + kArrayLength; }

  constexpr reference front() { return Data[0]; }
  constexpr reference back() { return Data[kArrayLength - 1]; }

  constexpr const_reference front() const { return Data[0]; }
  constexpr const_reference back() const { return Data[kArrayLength - 1]; }

  [[nodiscard]] constexpr size_t size() const { return kArrayLength; }

  /// Python-like iterator with key-value pair.
  /// \return an object that can iterate array in key-value pair.
  auto items() {
    struct ItemsIterator {
      EnumArray &Self;

      explicit ItemsIterator(EnumArray &Self) : Self(Self) {}

      paired_iterator begin() { return {Self, 0}; }

      paired_iterator end() { return {Self, kArrayLength}; }
    };

    return ItemsIterator(*this);
  }

  constexpr reference at(EnumT Index) {
    return Data[static_cast<size_t>(Index)];
  }

  constexpr const_reference at(EnumT Index) const {
    return Data[static_cast<size_t>(Index)];
  }

  constexpr reference operator[](EnumT Index) { return at(Index); }
  constexpr const_reference operator[](EnumT Index) const { return at(Index); }
}; // end class EnumArray
} // end namespace optimium::runtime

#endif // OPTIMIUM_RUNTIME_UTILS_ENUM_ARRAY_H