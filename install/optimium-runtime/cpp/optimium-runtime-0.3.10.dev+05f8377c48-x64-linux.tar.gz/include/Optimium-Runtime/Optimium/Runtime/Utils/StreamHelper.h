//===-- StreamHelper.h - Helper functions for std::ostream ------*- C++ -*-===//
//
// This file is part of Optimium-Runtime. Confidential and proprietary.
//
// Copyright (c) 2022~2023 ENERZAi Corporation.
// All Rights Reserved.
//
//===----------------------------------------------------------------------===//
///
/// \file
/// This file contains set of stream insertion operator for \c std::ostream
/// to stream out enumerations and classes.
///
//===----------------------------------------------------------------------===//
#ifndef OPTIMIUM_RUNTIME_UTILS_STREAM_HELPER_H
#define OPTIMIUM_RUNTIME_UTILS_STREAM_HELPER_H

#include "Optimium/Runtime.h"
#include "Optimium/Runtime/Export.h"

#include <ostream>

namespace optimium::runtime {
inline std::ostream &operator<<(std::ostream &OS, const VersionTuple &Value) {
  OS << ::toString(Value);
  return OS;
}

inline std::ostream &operator<<(std::ostream &OS, PlatformKind Value) {
  OS << toString(Value);
  return OS;
}

inline std::ostream &operator<<(std::ostream &OS, DeviceKind Value) {
  OS << toString(Value);
  return OS;
}

inline std::ostream &operator<<(std::ostream &OS, const Device &Value) {
  OS << Value.toString();
  return OS;
}

inline std::ostream &operator<<(std::ostream &OS, const Capability &Value) {
  OS << Value.toString();
  return OS;
}

inline std::ostream &operator<<(std::ostream &OS, X86FeatureKind Value) {
  OS << toString(Value);
  return OS;
}

inline std::ostream &operator<<(std::ostream &OS, ARMFeatureKind Value) {
  OS << toString(Value);
  return OS;
}

inline std::ostream &operator<<(std::ostream &OS, SPIRVFeatureKind Value) {
  OS << toString(Value);
  return OS;
}

inline std::ostream &operator<<(std::ostream &OS, SPIRVTarget Value) {
  OS << toString(Value);
  return OS;
}

inline std::ostream &operator<<(std::ostream &OS, ElementType Value) {
  OS << toString(Value);
  return OS;
}

inline std::ostream &operator<<(std::ostream &OS, const Shape &Value) {
  OS << Value.toString();
  return OS;
}

inline std::ostream &operator<<(std::ostream &OS, const Tensor &Value) {
  OS << Value.toString();
  return OS;
}

inline std::ostream &operator<<(std::ostream &OS,
                                const QuantizationParams &Value) {
  OS << Value.toString();
  return OS;
}

inline std::ostream &operator<<(std::ostream &OS,
                                const QuantizationScheme &Value) {
  OS << Value.toString();
  return OS;
}

inline std::ostream &operator<<(std::ostream &OS, const TensorInfo &Value) {
  OS << Value.toString();
  return OS;
}

inline std::ostream &operator<<(std::ostream &OS, ProfileKind Value) {
  OS << toString(Value);
  return OS;
}

inline std::ostream &operator<<(std::ostream &OS, const ProfileData &Value) {
  OS << Value.toString();
  return OS;
}

inline std::ostream &operator<<(std::ostream &OS, InferStatus Value) {
  OS << toString(Value);
  return OS;
}

inline std::ostream &operator<<(std::ostream &OS, Status Value) {
  OS << toString(Value);
  return OS;
}

inline std::ostream &operator<<(std::ostream &OS, const Error &Value) {
  OS << Value.toString();
  return OS;
}
} // end namespace optimium::runtime

#endif // OPTIMIUM_RUNTIME_UTILS_STREAM_HELPER_H