//===-- Result.h - Represents failable result -------------------*- C++ -*-===//
//
// This file is part of Optimium-Runtime. Confidential and proprietary.
//
// Copyright (c) 2022~2023 ENERZAi Corporation.
// All Rights Reserved.
//
//===----------------------------------------------------------------------===//
///
/// \file
///
/// \ref https://yegor.pomortsev.com/post/result-type
/// \ref https://github.com/SerenityOS/serenity/blob/master/AK/Try.h
///
//===----------------------------------------------------------------------===//
#ifndef OPTIMIUM_RUNTIME_RESULT_H
#define OPTIMIUM_RUNTIME_RESULT_H

#include "Optimium/Runtime/Export.h"

#include <cassert>
#include <cstdint>
#include <optional>
#include <string>
#include <variant>

namespace optimium::runtime {
// clang-format off
#define OPTIMIUM_RT_STATUS_ENUM(Op)                                              \
    Op(InvalidArgument)                                                        \
    Op(InvalidState)                                                           \
    Op(InvalidModel)                                                           \
    Op(InvalidExtension)                                                       \
    Op(UnsupportedModel)                                                       \
    Op(ModelLoadError)                                                         \
    Op(RequestError)                                                           \
    Op(DuplicatedExtension)                                                    \
    Op(TypeMismatch)                                                           \
    Op(DeviceError)                                                            \
    Op(DeviceNotFound)                                                         \
    Op(ExtensionError)                                                         \
    Op(InferError)                                                             \
    Op(InferCanceled)                                                          \
    Op(OutOfResource)                                                          \
    Op(InvalidOperation)                                                       \
    Op(InitFailure)                                                            \
    Op(RemoteError)                                                            \
    Op(IOError)                                                                \
    Op(NetworkError)                                                           \
    Op(OSError)                                                                \
    Op(NotImplemented)                                                         \
    Op(GeneralError)                                                           \
    Op(InvalidContainer)                                                       \
    Op(CorruptedContainer)                                                     \
    Op(ProtectedContainer)
// clang-format on

enum class Status : uint32_t {
#define OP(V) V,
  OPTIMIUM_RT_STATUS_ENUM(OP)
#undef OP
      Last = ProtectedContainer
}; // end enum Status

struct OPTIMIUM_RT_API Error {
  explicit Error(Status S, std::string Message)
      : Reason(S), Message(std::move(Message)) {}

  Status Reason;
  std::string Message;

  [[nodiscard]] Error wraps(enum Status NewReason, std::string Message) const;

  [[nodiscard]] std::string toString() const;
}; // end struct Err

template <typename ResultT>
class [[nodiscard]] Result final {
public:
  // NOLINTNEXTLINE(google-explicit-constructor) : Allow implicit conversion
  Result(ResultT &&Success) : Value(std::move(Success)) {}

  template <typename... ArgTs>
  // NOLINTNEXTLINE(google-explicit-constructor) : Allow implicit conversion
  Result(ArgTs &&...Args) : Value(ResultT(std::forward<ArgTs>(Args)...)) {}

  // NOLINTNEXTLINE(google-explicit-constructor) : Allow implicit conversion
  Result(Error Err) : Value(std::move(Err)) {}

  [[nodiscard]] bool ok() const {
    return !std::holds_alternative<Error>(Value);
  }

  [[nodiscard]] ResultT &&value() {
    assert(ok() && "cannot get value from error");
    return std::move(std::get<ResultT>(Value));
  }

  [[nodiscard]] const ResultT &ref() const {
    assert(ok() && "cannot get value from error");
    return std::get<ResultT>(Value);
  }

  [[nodiscard]] const Error &error() const {
    assert(!ok() && "cannot get error from normal value");
    return std::get<Error>(Value);
  }

  bool operator==(Status S) const {
    if (ok())
      return false;

    return error().Reason == S;
  }

  bool operator!=(Status S) const {
    if (ok())
      return false;

    return error().Reason != S;
  }

private:
  std::variant<ResultT, Error> Value;
}; // end class Result<ResultT>

struct Ok {};

template <>
class [[nodiscard]] Result<void> final {
public:
  // NOLINTNEXTLINE(google-explicit-constructor) : Allow implicit conversion
  Result(Ok &&) {}

  // NOLINTNEXTLINE(google-explicit-constructor) : Allow implicit conversion
  Result(Error Err) : Err(std::move(Err)) {}

  [[nodiscard]] bool ok() const { return !Err.has_value(); }

  [[nodiscard]] const Error &error() const {
    assert(!ok() && "cannot get error from normal value");
    return *Err;
  }

  bool operator==(Status S) const {
    if (ok())
      return false;

    return error().Reason == S;
  }

  bool operator!=(Status S) const {
    if (ok())
      return false;

    return error().Reason != S;
  }

private:
  std::optional<Error> Err;
}; // end class Result<void>

#define TRY(Expr)                                                              \
  ({                                                                           \
    auto _result_ = (Expr);                                                    \
    if (!_result_.ok())                                                        \
      return _result_.error();                                                 \
    _result_.value();                                                          \
  })

#define TRY_MESSAGE(Expr, Reason, Message)                                     \
  ({                                                                           \
    auto _result_ = (Expr);                                                    \
    if (!_result_.ok())                                                        \
      return _result_.error().wraps(Reason, Message);                          \
    _result_.value();                                                          \
  })

#define CHECK(Expr)                                                            \
  ({                                                                           \
    auto _result_ = (Expr);                                                    \
    if (!_result_.ok())                                                        \
      return _result_.error();                                                 \
  })

#define CHECK_MESSAGE(Expr, Reason, Message)                                   \
  ({                                                                           \
    auto _result_ = (Expr);                                                    \
    if (!_result_.ok())                                                        \
      return _result_.error().wraps(Reason, Message);                          \
  })

#define SUPPRESS(Expr, Message, ...)                                           \
  ({                                                                           \
    auto _result_ = (Expr);                                                    \
    if (!_result_.ok())                                                        \
      warning(TAG, Message ": {}", _result_.error(), ##__VA_ARGS__);           \
  })

///
/// \param Value
/// \return
OPTIMIUM_RT_API std::string_view toString(Status Value);
} // end namespace optimium::runtime

#endif // OPTIMIUM_RUNTIME_RESULT_H