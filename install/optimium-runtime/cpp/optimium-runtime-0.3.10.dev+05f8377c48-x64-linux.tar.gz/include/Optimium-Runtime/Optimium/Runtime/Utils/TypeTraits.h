//===-- TypeTraits.h - Type trait helpers -----------------------*- C++ -*-===//
//
// This file is part of Optimium-Runtime. Confidential and proprietary.
//
// Copyright (c) 2022~2023 ENERZAi Corporation.
// All Rights Reserved.
//
//===----------------------------------------------------------------------===//
///
/// \file
/// This file contains definitions of type trait helpers.
///
//===----------------------------------------------------------------------===//
#ifndef OPTIMIUM_RUNTIME_UTILS_TYPE_TRAITS_H
#define OPTIMIUM_RUNTIME_UTILS_TYPE_TRAITS_H

#include <type_traits>

namespace {
/// Traits that check given type is one of expected types.
/// \tparam Type a type to check.
/// \tparam Expects type list of expected types.
template <typename Type, typename... Expects>
constexpr bool IsOneOf = std::disjunction_v<std::is_same<Type, Expects>...>;

/// Traits that remove reference, const and volatile from given type.
/// \tparam Type a type to unveil.
template <typename Type>
using Unveiled = std::remove_reference_t<std::remove_cv_t<Type>>;

/// Traits that check given type is same as expected type.
/// \tparam Type a type to check.
/// \tparam Expected expected type.
template <typename Type, typename Expected>
constexpr bool Is = std::is_same_v<Unveiled<Type>, Expected>;

/// Traits that check given type is integral type (\c bool excluded).
/// \tparam Type a type to check.
template <typename Type>
constexpr bool IsInt =
    std::conjunction_v<std::negation<std::is_same<Type, bool>>,
                       std::is_integral<Type>>;

/// Traits that check given type is integral type (\c bool excluded).
/// \tparam Type a type to check.
template <typename Type>
constexpr bool IsSignedInt =
    std::conjunction_v<std::negation<std::is_same<Type, bool>>,
                       std::is_integral<Type>, std::is_signed<Type>>;

/// Traits that check given type is integral type (\c bool excluded).
/// \tparam Type a type to check.
template <typename Type>
constexpr bool IsUnsignedInt =
    std::conjunction_v<std::negation<std::is_same<Type, bool>>,
                       std::is_integral<Type>,
                       std::negation<std::is_signed<Type>>>;

/// Traits that check given type is floating point type.
/// \tparam Type a type to check.
template <typename Type>
constexpr bool IsFloat = std::is_floating_point_v<Type>;
} // end anonymous namespace

#endif // OPTIMIUM_RUNTIME_UTILS_TYPE_TRAITS_H