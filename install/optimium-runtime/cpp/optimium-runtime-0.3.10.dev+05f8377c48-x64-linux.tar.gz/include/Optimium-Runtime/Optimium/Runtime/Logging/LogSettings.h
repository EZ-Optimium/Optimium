//===-- LogSettings.h -  -*- C++ -*-===//
//
// This file is part of Optimium-Runtime. Confidential and proprietary.
//
// Copyright (c) 2022~2024 ENERZAi Corporation.
// All Rights Reserved.
//
//===----------------------------------------------------------------------===//
///
/// \file
///
///
//===----------------------------------------------------------------------===//
#ifndef OPTIMIUM_RUNTIME_LOGGING_SETTINGS_H
#define OPTIMIUM_RUNTIME_LOGGING_SETTINGS_H

#include "Optimium/Runtime/Export.h"
#include "Optimium/Runtime/Utils/NonCopyable.h"

#include <string>
#include <variant>

namespace optimium::runtime {
enum class LogLevel; // Defined in Optimium/Runtime/Logging/LogLevel.h

class WriterOption {
public:
  struct FileWriter {
    std::string LogPath;

    explicit FileWriter(std::string Path) : LogPath(std::move(Path)) {}
  };

  struct AndroidWriter {};

  struct ConsoleWriter {
    bool EnableColor;

    explicit ConsoleWriter(bool EnableColor = false)
        : EnableColor(EnableColor) {}
  };

  template <typename OptionT>
  WriterOption(OptionT Opt) : Option(std::forward<OptionT>(std::move(Opt))) {}

private:
  friend class LogSettings;

  std::variant<FileWriter, AndroidWriter, ConsoleWriter> Option;
}; // end class WriterOption

class OPTIMIUM_RT_API LogSettings final {
public:
  OPTIMIUM_RT_STATIC_CLASS(LogSettings)

  /// Enable log writer. Users can enable extra writer to save logs.
  /// \param Option
  static void addWriter(WriterOption Option);

  /// Get current log level.
  /// \return
  static LogLevel getLogLevel();

  ///
  /// \param New
  /// \return
  static LogLevel setLogLevel(LogLevel New);
}; // end class LogSettings
} // end namespace optimium::runtime

#endif // OPTIMIUM_RUNTIME_LOGGING_SETTINGS_H