//===-- Float16.h - Software-implement half precision fp --------*- C++ -*-===//
//
// This file is part of Optimium-Runtime. Confidential and proprietary.
//
// Copyright (c) 2022~2023 ENERZAi Corporation.
// All Rights Reserved.
//
//===----------------------------------------------------------------------===//
///
/// \file
/// This file contains definition of \c float16 (or \c half) which represents
/// half precision floating point number.
///
//===----------------------------------------------------------------------===//
#ifndef OPTIMIUM_RUNTIME_TYPES_FLOAT16_H
#define OPTIMIUM_RUNTIME_TYPES_FLOAT16_H

#include "Optimium/Runtime/Export.h"
#include "Optimium/Runtime/Utils/BitCast.h"

#include <cstdint>
#include <limits>

namespace optimium::runtime {
/// Software-implemented float16 (half).
/// \see
/// https://en.wikipedia.org/wiki/Half-precision_floating-point_format
class OPTIMIUM_RT_API float16 final {
  uint16_t Raw = 0;

public:
  static constexpr struct {
  } raw{};

  constexpr float16() = default;

  /* implicit */
  constexpr float16(decltype(raw), uint16_t Raw) : Raw(Raw) {}

  /* implicit */
  constexpr float16(float Value) : Raw(convert(Value)) {}

  /* implicit */
  constexpr operator float() const { return convert(Raw); }

  constexpr bool operator==(const float16 &Other) const {
    return cmp(Raw, Other.Raw) == 0;
  }

  constexpr bool operator!=(const float16 &Other) const {
    return !(operator==(Other));
  }

  constexpr bool operator<(const float16 &Other) const {
    return cmp(Raw, Other.Raw) < 0;
  }

  constexpr bool operator>(const float16 &Other) const {
    return cmp(Raw, Other.Raw) > 0;
  }

  constexpr bool operator<=(const float16 &Other) const {
    return !(operator>(Other));
  }

  constexpr bool operator>=(const float16 &Other) const {
    return !(operator<(Other));
  }

  constexpr friend float16 operator+(float16, float16);
  constexpr friend float16 operator-(float16, float16);
  constexpr friend float16 operator*(float16, float16);
  constexpr friend float16 operator/(float16, float16);

  constexpr float16 &operator++() {
    (*this) += 1.0f;
    return *this;
  }

  constexpr float16 operator++(int) {
    auto Old = *this;
    operator++();
    return Old;
  }

  constexpr float16 &operator--() {
    (*this) -= 1.0f;
    return *this;
  }

  constexpr float16 operator--(int) {
    auto Old = *this;
    operator--();
    return Old;
  }

  constexpr float16 &operator+=(float16 Other) {
    (*this) = (*this) + Other;
    return *this;
  }

  constexpr float16 &operator-=(float16 Other) {
    (*this) = (*this) - Other;
    return *this;
  }

  constexpr float16 &operator*=(float16 Other) {
    (*this) = (*this) * Other;
    return *this;
  }

  constexpr float16 &operator/=(float16 Other) {
    (*this) = (*this) / Other;
    return *this;
  }

  constexpr float16 operator-() const {
    uint16_t New = Raw ^ kSignMask;
    return {raw, New};
  }

  constexpr float16 operator+() const { return *this; }

private:
  static constexpr uint16_t kSignMask = 0x8000u;
  static constexpr uint16_t kExponentMask = 0x7C00u;
  static constexpr auto kExponentShift = 10;
  static constexpr auto kBias = 31;
  static constexpr uint16_t kMantissaMask = 0x03FFu;

  static constexpr uint32_t kF32SignMask = 0x80000000u;
  static constexpr uint32_t kF32ExponentMask = 0x7F800000u;
  static constexpr auto kF32Bias = 127;
  static constexpr uint32_t kF32MantissaMask = 0x007FFFFFu;
  static constexpr auto kF32ExponentShift = 23;

  inline static constexpr uint16_t convert(float);
  inline static constexpr float convert(uint16_t);

  static constexpr int cmp(uint16_t Left, uint16_t Right) {
    if (Left == Right)
      return 0;

    bool Negate = (Left & kSignMask) == kSignMask;

    if ((Left & kSignMask) != (Right & kSignMask))
      return Negate ? -1 : 1;

    auto LeftExp = (Left & kExponentMask);
    auto RightExp = (Right & kExponentMask);

    if (LeftExp != RightExp) {
      return Negate ^ (LeftExp < RightExp) ? -1 : 1;
    }

    auto LeftMantissa = (Left & kMantissaMask);
    auto RightMantissa = (Right & kMantissaMask);

    return Negate ^ (LeftMantissa < RightMantissa) ? -1 : 1;
  }
}; // end class float16

using half = float16;

namespace literals {
inline float16 operator""_hf(long double Float) { return {float(Float)}; }
inline float16 operator""_hf(unsigned long long int Int) {
  return {float(Int)};
}
} // namespace literals
} // end namespace optimium::runtime

template <>
class std::numeric_limits<optimium::runtime::float16> {
  using float16 = optimium::runtime::float16;

public:
  static constexpr bool is_specialized = true;
  static constexpr bool is_signed = true;
  static constexpr bool is_integer = false;
  static constexpr bool is_exact = false;
  static constexpr bool has_infinity = true;
  static constexpr bool has_quiet_NaN = true;
  static constexpr bool has_signaling_NaN = true;
  static constexpr std::float_denorm_style has_denorm = std::denorm_present;
  static constexpr bool has_denorm_loss = true;
  static constexpr std::float_round_style round_style = std::round_to_nearest;
  static constexpr bool is_iec559 = true;
  static constexpr bool is_bounded = true;
  static constexpr bool is_modulo = false;
  static constexpr int digits = 11;
  static constexpr int digits10 = 3;
  static constexpr int max_digits10 = 5;
  static constexpr int radix = 2;
  static constexpr int min_exponent = -13;
  static constexpr int min_exponent10 = -4;
  static constexpr int max_exponent = 16;
  static constexpr int max_exponent10 = 4;
  static constexpr float16 min() noexcept {
    return {float16::raw, 0b0'00001'0000000000u}; // 1.0p-14
  }
  static constexpr float16 lowest() noexcept {
    return {float16::raw, 0b1'11110'1111111111u}; // -1.ffcp+127
  }
  static constexpr float16 max() noexcept {
    return {float16::raw, 0b0'11110'1111111111u}; // 1.ffcp+127
  }
  static constexpr float16 epsilon() noexcept {
    return {float16::raw, 0b0'01010'0000000000u}; // 1.0p-10
  }
  static constexpr float16 round_error() noexcept {
    return {float16::raw, 0b0'01110'0000000000u}; // 1.0p-1
  }
  static constexpr float16 infinity() noexcept {
    return {float16::raw, 0b0'11111'0000000000u};
  }
  static constexpr float16 quiet_NaN() noexcept {
    return {float16::raw, 0b0'11111'1111111111u};
  }
  static constexpr float16 signaling_NaN() noexcept {
    return {float16::raw, 0b0'11111'0111111111u};
  }
  static constexpr float16 denorm_min() noexcept {
    return {float16::raw, 0b0'00000'0000000001u}; // 1.0p-23
  }
}; // end class std::numeric_limits<optimium::runtime::float16>

namespace optimium::runtime {
inline constexpr float16 operator+(float16 Left, float16 Right) { return Left; }

inline constexpr float16 operator-(float16 Left, float16 Right) { return Left; }

inline constexpr float16 operator*(float16 Left, float16 Right) { return Left; }

inline constexpr float16 operator/(float16 Left, float16 Right) { return Left; }

inline constexpr uint16_t float16::convert(float Value) {
  auto Float = bit_cast<uint32_t>(Value);

  uint16_t Sign = (Float & kF32SignMask) >> 16;

  auto Mantissa =
      (Float & kF32MantissaMask) >> (kF32ExponentShift - kExponentShift);
  if (Float & (1 << 9)) {
    Mantissa += 1; // emulate rounding
  }

  auto Exponent =
      int((Float & kF32ExponentShift) >> kF32ExponentShift) - kF32Bias + kBias;

  if (Exponent < 0)
    return (-std::numeric_limits<float16>::infinity()).Raw;

  if (Exponent > 63)
    return std::numeric_limits<float16>::infinity().Raw;

  return uint16_t(Sign | Exponent | Mantissa);
}

inline constexpr float float16::convert(uint16_t Value) {
  uint32_t Sign = (Value & kSignMask) << 16;
  uint32_t Mantissa = (Value & kMantissaMask)
                      << (kF32ExponentShift - kExponentShift);
  uint32_t Exponent =
      ((Value & kExponentMask) >> kExponentShift) - kBias + kF32Bias;
  uint32_t Float = (Sign | (Exponent << kF32ExponentShift) | Mantissa);
  return bit_cast<float>(Float);
}
} // end namespace optimium::runtime

#endif // OPTIMIUM_RUNTIME_TYPES_FLOAT16_H