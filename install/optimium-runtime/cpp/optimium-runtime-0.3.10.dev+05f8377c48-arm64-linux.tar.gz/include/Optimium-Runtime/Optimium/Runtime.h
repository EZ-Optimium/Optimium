//===-- Runtime.h - header for type-once-include-all ------------*- C++ -*-===//
//
// This file is part of Optimium-Runtime. Confidential and proprietary.
//
// Copyright (c) 2022~2023 ENERZAi Corporation.
// All Rights Reserved.
//
//===----------------------------------------------------------------------===//
///
/// \file This file is for busy person who does not have time to type.
/// Notice that this file only includes public APIs. To use private APIs or
/// Extension APIs who makes internal functionalities and/or extensions
/// should include necessary files manually.
///
//===----------------------------------------------------------------------===//
#ifndef OPTIMIUM_RUNTIME_H
#define OPTIMIUM_RUNTIME_H

#include "Optimium/Runtime/Capability.h"
#include "Optimium/Runtime/Context.h"
#include "Optimium/Runtime/Device.h"
#include "Optimium/Runtime/Host.h"
#include "Optimium/Runtime/InferRequest.h"
#include "Optimium/Runtime/Model.h"
#include "Optimium/Runtime/Platform.h"
#include "Optimium/Runtime/Profile.h"
#include "Optimium/Runtime/Tensor.h"

#endif // OPTIMIUM_RUNTIME_H