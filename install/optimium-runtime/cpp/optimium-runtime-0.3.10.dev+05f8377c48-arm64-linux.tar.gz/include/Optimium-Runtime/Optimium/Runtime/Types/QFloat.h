//===-- QFloat.h - Represents quantized floating point numbers --*- C++ -*-===//
//
// This file is part of Optimium-Runtime. Confidential and proprietary.
//
// Copyright (c) 2022~2023 ENERZAi Corporation.
// All Rights Reserved.
//
//===----------------------------------------------------------------------===//
///
/// \file
/// This file contains definition of \c qsfloat8, \c qufloat8, \c qsfloat16 and
/// \c qufloat16 that are represent quantized floating point numbers in 8-bit
/// and 16-bit each.
///
//===----------------------------------------------------------------------===//
#ifndef OPTIMIUM_RUNTIME_TYPES_QFLOAT_H
#define OPTIMIUM_RUNTIME_TYPES_QFLOAT_H

#include "Optimium/Runtime/Export.h"
#include "Optimium/Runtime/Utils/ArrayRef.h"

#include <cstdint>

namespace optimium::runtime {
struct QuantizationParams;

#define DECLARE_QUANTIZATION_TYPE(Name, BasisType)                             \
  class OPTIMIUM_RT_API Name final {                                           \
    BasisType Raw = 0;                                                         \
                                                                               \
  public:                                                                      \
    using BaseType = BasisType;                                                \
                                                                               \
    OPTIMIUM_RT_DEFAULT_COPYABLE(Name)                                         \
    OPTIMIUM_RT_DEFAULT_MOVABLE(Name)                                          \
                                                                               \
    constexpr Name() = default;                                                \
                                                                               \
    explicit constexpr Name(BasisType Raw) : Raw(Raw) {}                       \
                                                                               \
    BasisType raw() const { return Raw; }                                      \
                                                                               \
    static Name quantize(float Value, const QuantizationParams &Params);       \
                                                                               \
    static void quantize(ArrayRef<float> In, MutableArrayRef<Name> Out,        \
                         const QuantizationParams &Params);                    \
                                                                               \
    float dequantize(const QuantizationParams &Params);                        \
                                                                               \
    static void dequantize(ArrayRef<Name> In, MutableArrayRef<float> Out,      \
                           const QuantizationParams &Params);                  \
  }

/// Represents quantized float in 8-bit-sized signed integer.
DECLARE_QUANTIZATION_TYPE(qsfloat8, int8_t);

/// Represents quantized float in 8-bit-sized unsigned integer.
DECLARE_QUANTIZATION_TYPE(qufloat8, uint8_t);

/// Represents quantized float in 16-bit-sized signed integer.
DECLARE_QUANTIZATION_TYPE(qsfloat16, int16_t);

/// Represents quantized float in 16-bit-sized unsigned integer.
DECLARE_QUANTIZATION_TYPE(qufloat16, uint16_t);
} // end namespace optimium::runtime

#endif // OPTIMIUM_RUNTIME_TYPES_QFLOAT_H