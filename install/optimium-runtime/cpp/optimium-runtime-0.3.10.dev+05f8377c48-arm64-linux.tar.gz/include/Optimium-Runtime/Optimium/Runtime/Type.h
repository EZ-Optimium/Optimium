//===-- Type.h - Type representation of a tensor ----------------*- C++ -*-===//
//
// This file is part of Optimium-Runtime. Confidential and proprietary.
//
// Copyright (c) 2022~2023 ENERZAi Corporation.
// All Rights Reserved.
//
//===----------------------------------------------------------------------===//
///
/// \file
/// This file contains the declaration of \c ElementType enum and
/// additional functions.
///
//===----------------------------------------------------------------------===//
#ifndef OPTIMIUM_RUNTIME_TYPE_H
#define OPTIMIUM_RUNTIME_TYPE_H

#include "Optimium/Runtime/Export.h"
#include "Optimium/Runtime/Types/BFloat16.h"
#include "Optimium/Runtime/Types/Float16.h"
#include "Optimium/Runtime/Types/QFloat.h"
#include "Optimium/Runtime/Types/TFloat32.h"
#include "Optimium/Runtime/Utils/TypeTraits.h"

#include <array>
#include <cstdint>
#include <string_view>

namespace optimium::runtime {
// clang-format off
#define OPTIMIUM_RT_ELEMENT_TYPE_ENUM(Op) \
  Op(I8) \
  Op(U8) \
  Op(I16) \
  Op(U16) \
  Op(I32) \
  Op(U32) \
  Op(I64) \
  Op(U64) \
  Op(F16) \
  Op(F32) \
  Op(F64) \
  Op(QS8) \
  Op(QU8) \
  Op(QS16) \
  Op(QU16) \
  Op(BF16) \
  Op(TF32) \
  Op(Bool) \
  Op(String)
// clang-format on

/// Represents type of the element.
enum class ElementType {
/// \var ElementType::I8
///      signed, 8bit-sized integer.
/// \var ElementType::U8
///      unsigned, 8bit-sized integer.
/// \var ElementType::I16
///      signed, 16bit-sized integer.
/// \var ElementType::U16
///      unsigned, 16bit-sized integer.
/// \var ElementType::I32
///      signed, 32bit-sized integer.
/// \var ElementType::U32
///      unsigned, 32bit-sized integer.
/// \var ElementType::I64
///      signed, 64bit-sized integer.
/// \var ElementType::U64
///      unsigned, 64bit-sized integer.
/// \var ElementType::F16
///      16bit-sized floating point. (a.k.a half)
/// \var ElementType::F32
///      32bit-sized floating point. (a.k.a float)
/// \var ElementType::F64
///      64bit-sized floating point. (a.k.a double)
/// \var ElementType::QS8
///      8bit-sized quantized floating point, signed
/// \var ElementType::QU8
///      8bit-sized quantized floating point, unsigned
/// \var ElementType::QS16
///      16bit-sized quantized floating point, signed
/// \var ElementType::QU16
///      16bit-sized quantized floating point, unsigned
/// \var ElementType::BF16
///      16bit-sized brain floating point.
/// \var ElementType::TF32
///      tensor float 32.
/// \var ElementType::Bool
///      bitwise boolean.
/// \var ElementType::String
///      string of 8bit characters.
///      It does not force user to use specific encoding.
///      Users should care of it.
#define OP(Value) Value,
  OPTIMIUM_RT_ELEMENT_TYPE_ENUM(OP)
#undef OP
      Last = String
}; // end enum ElementType

/// Get size of the type.
/// \param Type a \c ElementType to get size.
/// \return \c size_t that represents size of the type.
OPTIMIUM_RT_API size_t getSizeOfElement(ElementType Type);

/// Convert \c ElementType to readable string.
/// \param Value value for convert to string.
/// \return a string that represents corresponding \c ElementType.
OPTIMIUM_RT_API std::string_view toString(ElementType Value);

/// Get \c ElementType from primitive type.
/// \tparam T primitive type to be converted.
/// \return \c ElementType correspond to given primitive type \c T.
template <typename T>
constexpr ElementType getTypeFromPrimitive() {
  static_assert(IsOneOf<T, int8_t, uint8_t, int16_t, uint16_t, int32_t,
                        uint32_t, int64_t, uint64_t, half, float, double,
                        bfloat16, tfloat32, qsfloat8, qufloat8, qsfloat16,
                        qufloat16, bool, char *, std::string, std::string_view>,
                "unsupported type");

  if constexpr (std::is_same_v<T, int8_t>)
    return ElementType::I8;
  if constexpr (std::is_same_v<T, uint8_t>)
    return ElementType::U8;
  if constexpr (std::is_same_v<T, int16_t>)
    return ElementType::I16;
  if constexpr (std::is_same_v<T, uint16_t>)
    return ElementType::U16;
  if constexpr (std::is_same_v<T, int32_t>)
    return ElementType::I32;
  if constexpr (std::is_same_v<T, uint32_t>)
    return ElementType::U32;
  if constexpr (std::is_same_v<T, int64_t>)
    return ElementType::I64;
  if constexpr (std::is_same_v<T, uint64_t>)
    return ElementType::U64;
  if constexpr (std::is_same_v<T, half>)
    return ElementType::F16;
  if constexpr (std::is_same_v<T, float>)
    return ElementType::F32;
  if constexpr (std::is_same_v<T, double>)
    return ElementType::F64;
  if constexpr (std::is_same_v<T, qsfloat8>)
    return ElementType::QS8;
  if constexpr (std::is_same_v<T, qsfloat16>)
    return ElementType::QS16;
  if constexpr (std::is_same_v<T, bfloat16>)
    return ElementType::BF16;
  if constexpr (std::is_same_v<T, tfloat32>)
    return ElementType::TF32;
  if constexpr (std::is_same_v<T, qufloat8>)
    return ElementType::QU8;
  if constexpr (std::is_same_v<T, qufloat16>)
    return ElementType::QU16;
  if constexpr (std::is_same_v<T, bool>)
    return ElementType::Bool;
  if constexpr (std::is_same_v<T, char *> || std::is_same_v<T, std::string> ||
                std::is_same_v<T, std::string_view>)
    return ElementType::String;
}
} // end namespace optimium::runtime

#endif // OPTIMIUM_RUNTIME_TYPE_H