//===-- BFloat16.h - Software-implemented brain float-16 --------*- C++ -*-===//
//
// This file is part of Optimium-Runtime. Confidential and proprietary.
//
// Copyright (c) 2022~2023 ENERZAi Corporation.
// All Rights Reserved.
//
//===----------------------------------------------------------------------===//
///
/// \file
/// This file contains definition of \c bfloat16 (a.k.a brain floating point).
///
//===----------------------------------------------------------------------===//
#ifndef OPTIMIUM_RUNTIME_TYPES_BFLOAT16_H
#define OPTIMIUM_RUNTIME_TYPES_BFLOAT16_H

#include "Optimium/Runtime/Export.h"
#include "Optimium/Runtime/Utils/BitCast.h"

#include <cstdint>
#include <limits>

namespace optimium::runtime {
/// Software-implemented brain floating point.
/// \see
/// https://en.wikipedia.org/wiki/Bfloat16_floating-point_format
class OPTIMIUM_RT_API bfloat16 final {
  uint16_t Raw = 0;

public:
  static constexpr struct {
  } raw{};

  constexpr bfloat16() = default;

  constexpr bfloat16(decltype(raw), uint16_t Raw) : Raw(Raw) {}

  /* implicit */
  constexpr bfloat16(float Value) : Raw(convert(Value)) {}

  /* implicit */
  constexpr operator float() const { return convert(Raw); }

  constexpr bool operator==(const bfloat16 &Other) const {
    return cmp(Raw, Other.Raw) == 0;
  }

  constexpr bool operator!=(const bfloat16 &Other) const {
    return !(operator==(Other));
  }

  constexpr bool operator<(const bfloat16 &Other) const {
    return cmp(Raw, Other.Raw) < 0;
  }

  constexpr bool operator>(const bfloat16 &Other) const {
    return cmp(Raw, Other.Raw) > 0;
  }

  constexpr bool operator<=(const bfloat16 &Other) const {
    return !(operator>(Other));
  }

  constexpr bool operator>=(const bfloat16 &Other) const {
    return !(operator<(Other));
  }

  constexpr friend bfloat16 operator+(bfloat16, bfloat16);
  constexpr friend bfloat16 operator-(bfloat16, bfloat16);
  constexpr friend bfloat16 operator*(bfloat16, bfloat16);
  constexpr friend bfloat16 operator/(bfloat16, bfloat16);

  constexpr bfloat16 &operator++() {
    (*this) += 1.0f;
    return *this;
  }

  constexpr bfloat16 operator++(int) {
    auto Old = *this;
    operator++();
    return Old;
  }

  constexpr bfloat16 &operator--() {
    (*this) -= 1.0f;
    return *this;
  }

  constexpr bfloat16 operator--(int) {
    auto Old = *this;
    operator--();
    return Old;
  }

  constexpr bfloat16 &operator+=(bfloat16 Other) {
    *this = *this + Other;
    return *this;
  }

  constexpr bfloat16 &operator-=(bfloat16 Other) {
    *this = *this - Other;
    return *this;
  }

  constexpr bfloat16 &operator*=(bfloat16 Other) {
    *this = *this * Other;
    return *this;
  }

  constexpr bfloat16 &operator/=(bfloat16 Other) {
    *this = *this / Other;
    return *this;
  }

  constexpr bfloat16 operator-() const {
    uint16_t New = Raw ^ kSignMask;
    return {raw, New};
  }

  constexpr bfloat16 operator+() const { return *this; }

private:
  static constexpr auto kShift = 16;
  static constexpr uint16_t kSignMask = 0x8000u;
  static constexpr uint16_t kExponentMask = 0x7F80u;
  static constexpr uint16_t kMantissaMask = 0x007Fu;

  inline static constexpr uint16_t convert(float Value) {
    return bit_cast<uint32_t>(Value) >> kShift;
  }

  inline static constexpr float convert(uint16_t Value) {
    return bit_cast<float>(uint32_t(Value << kShift));
  }

  inline static constexpr int cmp(uint16_t Left, uint16_t Right) {
    if (Left == Right)
      return 0;

    bool Negate = (Left & kSignMask) == kSignMask;

    if ((Left & kSignMask) != (Right & kSignMask))
      return Negate ? -1 : 1;

    auto LeftExp = (Left & kExponentMask);
    auto RightExp = (Right & kExponentMask);

    if (LeftExp != RightExp) {
      return Negate ^ (LeftExp < RightExp) ? -1 : 1;
    }

    auto LeftMantissa = (Left & kMantissaMask);
    auto RightMantissa = (Right & kMantissaMask);

    return Negate ^ (LeftMantissa < RightMantissa) ? -1 : 1;
  }
}; // end class bfloat16

namespace literals {
inline bfloat16 operator""_bf(long double Float) { return bfloat16(Float); }
inline bfloat16 operator""_bf(unsigned long long Int) { return bfloat16(Int); }
} // namespace literals
} // end namespace optimium::runtime

template <>
class std::numeric_limits<optimium::runtime::bfloat16> {
  using bfloat16 = optimium::runtime::bfloat16;

public:
  static constexpr bool is_specialized = true;
  static constexpr bool is_signed = true;
  static constexpr bool is_integer = false;
  static constexpr bool is_exact = false;
  static constexpr bool has_infinity = true;
  static constexpr bool has_quiet_NaN = true;
  static constexpr bool has_signaling_NaN = true;
  static constexpr std::float_denorm_style has_denorm = std::denorm_present;
  static constexpr bool has_denorm_loss = true;
  static constexpr std::float_round_style round_style = std::round_to_nearest;
  static constexpr bool is_iec559 = true;
  static constexpr bool is_bounded = true;
  static constexpr bool is_modulo = false;
  static constexpr int digits = 8;
  static constexpr int digits10 = 3;
  static constexpr int max_digits10 = 5;
  static constexpr int radix = 2;
  static constexpr int min_exponent = -13;
  static constexpr int min_exponent10 = -4;
  static constexpr int max_exponent = 16;
  static constexpr int max_exponent10 = 4;
  static constexpr bfloat16 min() noexcept {
    return {bfloat16::raw, 0b0'00000001'0000000u}; // 1.0p-126
  }
  static constexpr bfloat16 lowest() noexcept {
    return {bfloat16::raw, 0b1'11111110'1111111u}; // -1.fep+127
  }
  static constexpr bfloat16 max() noexcept {
    return {bfloat16::raw, 0b0'11111110'1111111u}; // 1.fep+127
  }
  static constexpr bfloat16 epsilon() noexcept {
    return {bfloat16::raw, 0b0'01111000'0000000u}; // 1.p-7
  }
  static constexpr bfloat16 round_error() noexcept {
    return {bfloat16::raw, 0b0'01111110'0000000u}; // 1.0p-1
  }
  static constexpr bfloat16 infinity() noexcept {
    return {bfloat16::raw, 0b0'11111111'0000000u};
  }
  static constexpr bfloat16 quiet_NaN() noexcept {
    return {bfloat16::raw, 0b0'11111111'1111111u};
  }
  static constexpr bfloat16 signaling_NaN() noexcept {
    return {bfloat16::raw, 0b0'11111111'0111111u};
  }
  static constexpr bfloat16 denorm_min() noexcept {
    return {bfloat16::raw, 0b0'00000000'0000001u}; // 1.p-23
  }
}; // end class std::numeric_limits<optimium::runtime::bfloat16>

namespace optimium::runtime {
inline constexpr bfloat16 operator+(bfloat16 Left, bfloat16 Right) {

#if defined(OPTIMIUM_RT_USE_SW_BF16)

#else

#endif

  return Left;
}

inline constexpr bfloat16 operator-(bfloat16 Left, bfloat16 Right) {

#if defined(OPTIMIUM_RT_USE_SW_BF16)

#else

#endif

  return Left;
}

inline constexpr bfloat16 operator*(bfloat16 Left, bfloat16 Right) {

#if defined(OPTIMIUM_RT_USE_SW_BF16)

#else

#endif

  return Left;
}

inline constexpr bfloat16 operator/(bfloat16 Left, bfloat16 Right) {

#if defined(OPTIMIUM_RT_USE_SW_BF16)

#else

#endif

  return Left;
}
} // end namespace optimium::runtime

#endif // OPTIMIUM_RUNTIME_TYPES_BFLOAT16_H