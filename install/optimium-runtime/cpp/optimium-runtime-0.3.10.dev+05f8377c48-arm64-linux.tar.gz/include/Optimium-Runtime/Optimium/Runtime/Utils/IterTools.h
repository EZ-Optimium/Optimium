//===-- IterTools.h - Python-like iterator utils ----------------*- C++ -*-===//
//
// This file is part of Optimium-Runtime. Confidential and proprietary.
//
// Copyright (c) 2022~2023 ENERZAi Corporation.
// All Rights Reserved.
//
//===----------------------------------------------------------------------===//
///
/// \file
/// This file contains utility functions for range-based for loop.
///
//===----------------------------------------------------------------------===//
#ifndef OPTIMIUM_RUNTIME_UTILS_ITERTOOLS_H
#define OPTIMIUM_RUNTIME_UTILS_ITERTOOLS_H

#include <iterator>
#include <tuple>

namespace {
template <typename T, typename IndexT = int>
constexpr auto enumerate(T &&Iterable, IndexT Start = 0) {
  using IterT = decltype(std::begin(Iterable));

  struct Iterator {
    IndexT Index;
    IterT It;

    bool operator!=(const Iterator &Other) const { return It != Other.It; }

    Iterator &operator++() {
      ++Index;
      ++It;
      return *this;
    }

    auto operator*() { return std::tie(Index, *It); }

    Iterator(IndexT Index, IterT &&It) : Index(Index), It(std::move(It)) {}
  }; // end struct Iterator

  struct Wrapper {
    IndexT Start;
    T Iterable;

    auto begin() { return Iterator(Start, std::begin(Iterable)); }

    auto end() { return Iterator(0, std::end(Iterable)); }

    Wrapper(IndexT Start, T &&Iterable)
        : Start(Start), Iterable(std::forward<T>(Iterable)) {}
  }; // end struct Wrapper

  return Wrapper(Start, std::forward<T>(Iterable));
}

template <typename T>
constexpr auto range(T Begin, T End, T Step) {
  static_assert(std::is_arithmetic_v<T>, "range allows arithmetic types only.");

  struct Iterator {
    using iterator_category = std::forward_iterator_tag;
    using value_type = T;

    T Value;
    T Step;

    bool operator!=(const Iterator &Other) { return Value < Other.Value; }

    void operator++() { Value += Step; }

    auto operator*() const { return Value; }

    Iterator(T Value, T Step) : Value(Value), Step(Step) {}
  };

  struct Wrapper {
    T Begin, End, Step;

    auto begin() { return Iterator(Begin, Step); }

    auto end() { return Iterator(End, T(0)); }

    Wrapper(T Begin, T End, T Step) : Begin(Begin), End(End), Step(Step) {}
  };

  return Wrapper(Begin, End, Step);
}

template <typename T>
constexpr auto range(T Begin, T End) {
  return range<T>(Begin, End, T(1));
}

template <typename T>
constexpr auto range(T End) {
  return range<T>(T(0), End, T(1));
}

template <typename MappingT>
constexpr auto keys(MappingT &&Map) {
  using IterT = decltype(std::begin(Map));
  using KeyT = decltype(std::declval<IterT>()->first);

  struct Iterator {
    using iterator_category = std::forward_iterator_tag;
    using value_type = KeyT;

    IterT It;

    bool operator!=(const Iterator &Other) const { return It != Other.It; }

    Iterator &operator++() {
      ++It;
      return *this;
    }

    auto operator*() { return It->first; }

    explicit Iterator(IterT &&It) : It(std::move(It)) {}
  }; // end struct Iterator

  struct Wrapper {
    MappingT Map;

    auto begin() { return Iterator(std::begin(Map)); }

    auto end() { return Iterator(std::end(Map)); }

    explicit Wrapper(MappingT &&Map) : Map(std::forward<MappingT>(Map)) {}
  }; // end struct Wrapper

  return Wrapper(std::forward<MappingT>(Map));
}

template <typename MappingT>
constexpr auto values(MappingT &&Map) {
  using IterT = decltype(std::begin(Map));
  using ValueT = decltype(std::declval<IterT>()->second);

  struct Iterator {
    using iterator_category = std::forward_iterator_tag;
    using value_type = ValueT;

    IterT It;

    bool operator!=(const Iterator &Other) const { return It != Other.It; }

    Iterator &operator++() {
      ++It;
      return *this;
    }

    auto operator*() { return It->second; }

    explicit Iterator(IterT &&It) : It(std::move(It)) {}
  }; // end struct Iterator

  struct Wrapper {
    MappingT Map;

    auto begin() { return Iterator(std::begin(Map)); }

    auto end() { return Iterator(std::end(Map)); }

    explicit Wrapper(MappingT &&Map) : Map(std::forward<MappingT>(Map)) {}
  }; // end struct Wrapper

  return Wrapper(std::forward<MappingT>(Map));
}
} // end anonymous namespace

#endif // OPTIMIUM_RUNTIME_UTILS_ITERTOOLS_H