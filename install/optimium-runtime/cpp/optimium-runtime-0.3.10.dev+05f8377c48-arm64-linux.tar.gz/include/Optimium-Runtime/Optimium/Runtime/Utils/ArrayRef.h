//===-- ArrayRef.h - Reference to an array ----------------------*- C++ -*-===//
//
// This file is part of Optimium-Runtime. Confidential and proprietary.
//
// Copyright (c) 2023 ENERZAi Corporation.
// All Rights Reserved.
//
//===----------------------------------------------------------------------===//
///
/// \file
/// This file contains the definition of \c ArrayRef class, which represents
/// reference to an array. This class is same as LLVM's one but simplified.
///
//===----------------------------------------------------------------------===//
#ifndef OPTIMIUM_RUNTIME_UTILS_ARRAYREF_H
#define OPTIMIUM_RUNTIME_UTILS_ARRAYREF_H

#include "Optimium/Runtime/Utils/NonCopyable.h"

#include <cassert>
#include <cstdint>
#include <iterator>

namespace optimium::runtime {
/// Reference to an array.
/// \tparam T type of element in the array.
template <typename T>
class ArrayRef {
public:
  using value_type = T;
  using pointer = value_type *;
  using const_pointer = const value_type *;
  using reference = value_type &;
  using const_reference = const value_type &;
  using iterator = const_pointer;
  using const_iterator = const_pointer;
  using size_type = size_t;
  using difference_type = ptrdiff_t;

private:
  const T *Base = nullptr;
  size_t Size = 0;

public:
  OPTIMIUM_RT_DEFAULT_COPYABLE(ArrayRef);
  OPTIMIUM_RT_DEFAULT_MOVABLE(ArrayRef);

  ArrayRef() = default;

  constexpr ArrayRef(const T *Ptr, size_t Size) : Base(Ptr), Size(Size) {}

  template <size_t N>
  constexpr explicit ArrayRef(const T (&Array)[N]) : Base(Array), Size(N) {}

  template <typename ContainerT>
  explicit ArrayRef(const ContainerT &Container)
      : Base(std::data(Container)), Size(std::size(Container)) {
    static_assert(std::is_same_v<typename ContainerT::value_type, T>,
                  "Element type of Container must be equal to T.");
  }

  const T &at(size_t Index) const { return Base[Index]; }

  const T &operator[](size_t Index) const { return at(Index); }

  const_iterator begin() const { return Base; }

  const_iterator end() const { return Base + Size; }

  const T &front() const { return Base[0]; }

  const T &back() const { return Base[Size - 1]; }

  [[nodiscard]] bool empty() const { return Size == 0; }

  const T *data() const { return Base; }

  [[nodiscard]] size_t size() const { return Size; }

  ArrayRef<T> slice(size_t From, size_t Length) const {
    assert((From + Length < Size) && "out of bound.");

    return ArrayRef(Base + From, Length);
  }

  void cbegin() const { return begin(); }

  void cend() const { return end(); }
}; // end class ArrayRef

template <typename ContainerT>
ArrayRef(const ContainerT &) -> ArrayRef<typename ContainerT::value_type>;

/// Mutable reference to an array.
/// \tparam T type of element in the array.
template <typename T>
class MutableArrayRef {
public:
  using value_type = T;
  using pointer = value_type *;
  using const_pointer = const value_type *;
  using reference = value_type &;
  using const_reference = const value_type &;
  using iterator = pointer;
  using const_iterator = const_pointer;
  using size_type = size_t;
  using difference_type = ptrdiff_t;

private:
  T *Base = nullptr;
  size_t Size = 0;

public:
  OPTIMIUM_RT_DEFAULT_COPYABLE(MutableArrayRef);
  OPTIMIUM_RT_DEFAULT_MOVABLE(MutableArrayRef);

  MutableArrayRef() = default;

  constexpr MutableArrayRef(T *Ptr, size_t Size) : Base(Ptr), Size(Size) {}

  template <size_t N>
  constexpr explicit MutableArrayRef(T (&Array)[N]) : Base(Array), Size(N) {}

  template <typename ContainerT>
  explicit MutableArrayRef(ContainerT &Container)
      : Base(std::data(Container)), Size(std::size(Container)) {
    static_assert(std::is_same_v<typename ContainerT::value_type, T>,
                  "Element type of Container must be equal to T.");
  }

  T &at(size_t Index) { return Base[Index]; }

  T &operator[](size_t Index) { return at(Index); }

  iterator begin() { return Base; }

  iterator end() { return Base + Size; }

  T &front() { return Base[0]; }

  T &back() { return Base[Size - 1]; }

  [[nodiscard]] bool empty() const { return Size == 0; }

  T *data() { return Base; }

  [[nodiscard]] size_t size() const { return Size; }

  MutableArrayRef<T> slice(size_t From, size_t Length) const {
    assert((From + Length < Size) && "out of bound.");

    return MutableArrayRef(Base + From, Length);
  }

  ArrayRef<T> toArray() const { return ArrayRef(Base, Size); }
}; // end class MutableArrayRef

template <typename ContainerT>
MutableArrayRef(const ContainerT &)
    -> MutableArrayRef<typename ContainerT::value_type>;
} // end namespace optimium::runtime

#endif // OPTIMIUM_RUNTIME_UTILS_ARRAYREF_H