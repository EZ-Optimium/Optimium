//===-- ModelOptions.h - Options for loading model --------------*- C++ -*-===//
//
// This file is part of Optimium-Runtime. Confidential and proprietary.
//
// Copyright (c) 2022~2023 ENERZAi Corporation.
// All Rights Reserved.
//
//===----------------------------------------------------------------------===//
///
/// \file
/// This file contains definition of \c ModelOptions struct for loading a model.
///
//===----------------------------------------------------------------------===//
#ifndef OPTIMIUM_RUNTIME_MODEL_OPTIONS_H
#define OPTIMIUM_RUNTIME_MODEL_OPTIONS_H

#include "Optimium/Runtime/Config.h"
#include "Optimium/Runtime/Utils/Any.h"

namespace optimium::runtime {

/// Represents execution mode for a model.
enum class ExecutionMode {
  /// Mode that operations in the model are executed sequentially.
  Sequential,

  /// Mode that operations in the model are grouped and executed
  /// in parallel.
  Parallel
}; // end enum ExecutionMode

/// Represents options for loading a model.
struct ModelOptions {
  /// Enable profile mode.
  /// It is suggested that disable profiling mode on production.
  bool EnableProfile = false;

  /// Enable memory optimization.
  /// Can be disabled when getting intermediate tensors is needed for
  /// debugging purpose.
  bool EnableMemoryOptimization = true;

  /// Model execution mode.
  ExecutionMode Mode = ExecutionMode::Sequential;

  /// Passphrase for the model.
  std::string Passphrase = {};

  /// Options for devices.
  Dict Options = {};

  /// Set number of threads running the model.
  size_t ThreadsCount = 1;

  /// Priority of threads.
  int Nice = UnsetNice;

  /// Core indices for affinity of threads.
  std::vector<uint32_t> Cores;
}; // end struct ModelOptions
} // end namespace optimium::runtime

#endif // OPTIMIUM_RUNTIME_MODEL_OPTIONS_H