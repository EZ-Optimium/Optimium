//===-- Model.h - Represents ML model ---------------------------*- C++ -*-===//
//
// This file is part of Optimium-Runtime. Confidential and proprietary.
//
// Copyright (c) 2022~2023 ENERZAi Corporation.
// All Rights Reserved.
//
//===----------------------------------------------------------------------===//
///
/// \file This file contains definition of Model class.
///
//===----------------------------------------------------------------------===//
#ifndef OPTIMIUM_RUNTIME_MODEL_H
#define OPTIMIUM_RUNTIME_MODEL_H

#include "Optimium/Runtime/Assert.h"
#include "Optimium/Runtime/Export.h"
#include "Optimium/Runtime/Utils/NonCopyable.h"

#include <cstdint>
#include <memory>
#include <string>
#include <vector>

namespace optimium::runtime {
namespace detail {
class ModelDetail;
} // end namespace detail

class Device;       // Defined in Optimium/Runtime/Device.h
class InferRequest; // Defined in Optimium/Runtime/InferRequest.h
struct TensorInfo;  // Defined in Optimium/Runtime/TensorInfo.h

template <typename>
class Result;

///
class OPTIMIUM_RT_API Model final {
public:
  OPTIMIUM_RT_NON_COPYABLE(Model)
  OPTIMIUM_RT_DEFAULT_MOVABLE(Model)

  Model() = default;

  /// Create new \c InferRequest.
  /// \return an \c InferRequest of the model.
  [[nodiscard]] Result<InferRequest> createRequest();

  /// Get information of input tensor by its index.
  /// \param Index index of input tensor.
  /// \return reference of \c TensorInfo that contains information of
  ///         the tensor.
  [[nodiscard]] Result<TensorInfo> getInputTensorInfo(int Index = 0) const;

  /// Get information of input tensor by its name.
  /// \param Name name of input tensor.
  /// \return reference of \c TensorInfo that contains information of
  ///         the tensor.
  [[nodiscard]] Result<TensorInfo>
  getInputTensorInfo(const std::string &Name) const;

  /// Get list of information of input tensors.
  /// \return
  [[nodiscard]] std::vector<TensorInfo> getInputTensorsInfo() const;

  /// Get list of name of input tensors.
  /// \return
  [[nodiscard]] std::vector<std::string> getInputTensorNames() const;

  /// Get count of input tensors.
  /// \return an integral value that represents count of input tensors.
  [[nodiscard]] int getInputTensorCount() const;

  /// Get information of output tensor by its index.
  /// \param Index index of output tensor.
  /// \return a \c TensorInfo that contains information of the tensor.
  [[nodiscard]] Result<TensorInfo> getOutputTensorInfo(int Index = 0) const;

  /// Get information of output tensor by its name.
  /// \param Name name of output tensor.
  /// \return a \c TensorInfo that contains information of the tensor.
  [[nodiscard]] Result<TensorInfo>
  getOutputTensorInfo(const std::string &Name) const;

  /// Get list of information of output tensors.
  /// \return
  [[nodiscard]] std::vector<TensorInfo> getOutputTensorsInfo() const;

  /// Get list of name of output tensors.
  /// \return
  [[nodiscard]] std::vector<std::string> getOutputTensorNames() const;

  /// Get count of output tensors.
  /// \return an integral value that represents count of output tensors.
  [[nodiscard]] int getOutputTensorCount() const;

  /// Get information of a tensor by its index.
  /// \param Index index of the tensor.
  /// \return reference of \c TensorInfo that contains information of
  ///         the tensor.
  [[nodiscard]] Result<TensorInfo> getTensorInfo(int Index = 0) const;

  /// Get information of a tensor by its name.
  /// \param Name name of the tensor.
  /// \return reference of \c TensorInfo that contains information of
  ///         the tensor.
  [[nodiscard]] Result<TensorInfo> getTensorInfo(const std::string &Name) const;

  /// Get list of information of tensors.
  /// \return
  [[nodiscard]] std::vector<TensorInfo> getTensorsInfo() const;

  /// Get list of name of tensors.
  /// \return
  [[nodiscard]] std::vector<std::string> getTensorsName() const;

  /// Get count of total tensors.
  /// \return an integral value that represents count of all tensors.
  [[nodiscard]] int getTensorCount() const;

  /// Get default layout of the model.
  /// \return a \c std::string_view that represents layout of the model.
  ///         This member function may return empty string.
  [[nodiscard]] std::string_view getModelLayout() const;

  /// Get name of the model.
  /// \return a \c std::string_view that represents name of the model.
  [[nodiscard]] std::string_view getName() const;

private:
  friend class Context;

  explicit Model(std::shared_ptr<detail::ModelDetail> Detail)
      : Detail(std::move(Detail)) {
    NEVER_BE_NULL(this->Detail);
  }

  std::shared_ptr<detail::ModelDetail> Detail;
}; // end class Model
} // end namespace optimium::runtime

#endif // OPTIMIUM_RUNTIME_MODEL_H
