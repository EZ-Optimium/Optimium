//===-- Platform.h - List of supported platforms by the runtime -*- C++ -*-===//
//
// This file is part of Optimium-Runtime. Confidential and proprietary.
//
// Copyright (c) 2022~2023 ENERZAi Corporation.
// All Rights Reserved.
//
//===----------------------------------------------------------------------===//
///
/// \file
/// This file contains declaration of \c PlatformKind that is an enumeration
/// type represents list of platforms supported by the runtime.
///
//===----------------------------------------------------------------------===//
#ifndef OPTIMIUM_RUNTIME_PLATFORM_H
#define OPTIMIUM_RUNTIME_PLATFORM_H

#include "Optimium/Runtime/Export.h"

#include <string_view>

namespace optimium::runtime {
// clang-format off
#define OPTIMIUM_RT_PLATFORM_KIND_ENUM(Op) \
  Op(TFLite) \
  Op(OpenVINO) \
  Op(SNPE) \
  Op(DVAPI) \
  Op(Vulkan) \
  Op(OpenCL) \
  Op(Native) \
  Op(CUDA) \
  OP(XNNPack)
// clang-format on

/// Represents kind of supported platforms.
///
/// \warning Must be same order with Platform.proto
///          except PLATFORM_TYPE_UNKNOWN.
enum class PlatformKind {
/// \var PlatformKind::TFLite
///      Tensorflow Lite
/// \var PlatformKind::OpenVINO
///      OpenVINO
/// \var PlatformKind::SNPE
///      Qualcomm Snapdragon Neural Processing Engine
/// \var PlatformKind::DVAPI
///      Kinara DVAPI
/// \var PlatformKind::Vulkan
///      Vulkan
/// \var PlatformKind::OpenCL
///      OpenCL
/// \var PlatformKind::Native
///      Native code - running on CPU.
/// \var PlatformKind::CUDA
///      NVidia CUDA
/// \var PlatformKind::XNNPack
///      Google XNNPack

#define OP(Value) Value,
  OPTIMIUM_RT_PLATFORM_KIND_ENUM(OP)
#undef OP
      Last = XNNPack
}; // end enum PlatformKind

/// Convert \c PlatformKind to readable string.
/// \param Value value for convert to string.
/// \return a string that represents corresponding \c PlatformKind.
OPTIMIUM_RT_API std::string_view toString(PlatformKind Value);
} // end namespace optimium::runtime

#endif // OPTIMIUM_RUNTIME_PLATFORM_H