//===-- ContextOptions.h - Options for the context --------------*- C++ -*-===//
//
// This file is part of Optimium-Runtime. Confidential and proprietary.
//
// Copyright (c) 2022~2023 ENERZAi Corporation.
// All Rights Reserved.
//
//===----------------------------------------------------------------------===//
///
/// \file
/// This file contains declaration of \c ContextOptions struct, which
/// contains options for construct the context.
///
//===----------------------------------------------------------------------===//
#ifndef OPTIMIUM_RUNTIME_CONTEXT_OPTIONS_H
#define OPTIMIUM_RUNTIME_CONTEXT_OPTIONS_H

#include "Optimium/Runtime/Logging/LogLevel.h"

#include <string>
#include <vector>

namespace optimium::runtime {
/// Contains options for construct the context.
struct ContextOptions {
  /// Additional path to scan extensions.
  std::vector<std::string> ExtensionPaths;

  /// Output path of fatal log.
  /// Defaults to "$CWD/optimium-runtime-fatal-<pid>.log"
  std::string FatalLogPath;
}; // end struct ContextOptions
} // end namespace optimium::runtime

#endif // OPTIMIUM_RUNTIME_CONTEXT_OPTIONS_H