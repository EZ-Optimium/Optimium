//===-- Context.h - Manages data and device across runtime ------*- C++ -*-===//
//
// This file is part of Optimium-Runtime. Confidential and proprietary.
//
// Copyright (c) 2022~2023 ENERZAi Corporation.
// All Rights Reserved.
//
//===----------------------------------------------------------------------===//
///
/// \file
/// This file contains the definition of \c Context class.
///
//===----------------------------------------------------------------------===//
#ifndef OPTIMIUM_RUNTIME_CONTEXT_H
#define OPTIMIUM_RUNTIME_CONTEXT_H

#include "Optimium/Runtime/ContextOptions.h"
#include "Optimium/Runtime/Device.h"
#include "Optimium/Runtime/Export.h"
#include "Optimium/Runtime/ModelOptions.h"
#include "Optimium/Runtime/Result.h"
#include "Optimium/Runtime/Utils/Any.h"
#include "Optimium/Runtime/Utils/ArrayRef.h"
#include "Optimium/Runtime/Utils/NonCopyable.h"
#include "Optimium/Runtime/Version.h"

#include <string>
#include <tuple>
#include <utility>
#include <vector>

namespace optimium::runtime {
namespace detail {
class ContextDetail;
} // end namespace detail

enum class ConnectionMethod; // Defined in Optimium/Runtime/Host.h
class Model;                 // Defined in Optimium/Runtime/Model.h
class RemoteContext;         // Defined in Optimium/Runtime/RemoteContext.h

/// Default connection port to remote server.
constexpr uint16_t kDefaultRemotePort = 32264;

/// Represents current state of the runtime.
class OPTIMIUM_RT_API Context final {
public:
  OPTIMIUM_RT_NON_COPYABLE(Context)

  Context() = default;

  Context(Context &&) noexcept;

  Context &operator=(Context &&) noexcept;

  ~Context() noexcept;

  /// Load a model from given path.
  /// \param Path a path of a model.
  /// \param Devices list of devices for execute the model.
  /// \param Options options to load model.
  /// \param Strict forbids the runtime to search devices from local if capable
  ///               devices was not found from given devices.
  ///               defaults to \c false.
  /// \return a \c Model.
  [[nodiscard]] Result<Model> loadModel(const std::string &Path,
                                        ArrayRef<Device> Devices = {},
                                        const ModelOptions &Options = {},
                                        bool Strict = false);

  /// Load a model from given path.
  /// \param Path a path of a model.
  /// \param Dev a \c Device for execute the model.
  /// \param Options options for extension to load model.
  /// \param Strict forbids the runtime to search devices from local if capable
  ///               devices was not found from given device.
  ///               defaults to \c false.
  /// \return a \c Model.
  [[nodiscard]] Result<Model> loadModel(const std::string &Path, Device Dev,
                                        const ModelOptions &Options = {},
                                        bool Strict = false);

  /// Connect to remote host.
  /// \param Address address of the remote.
  /// \param Kind connection method how to connect to the remote.
  /// \param Port port number to connect.
  /// \param EnableEncryption connect remote with encryption.
  ///                         Default to \c true. Disabling this is strongly
  ///                         discouraged.
  /// \return a \c RemoteContext that represents \c Context on remote host.
  Result<RemoteContext> connectRemote(const std::string &Address,
                                      ConnectionMethod Kind,
                                      uint16_t Port = kDefaultRemotePort,
                                      bool EnableEncryption = true);

  /// Get a device from localhost.
  /// \param Platform
  /// \param Device
  /// \param Index
  /// \param RequiredCapability pointer of \c Capability which express required
  ///                           capability of the device.
  /// \return a \c Device that capable for given requirements.
  /// \note There are convenience wrappers also defined in \c Device class.
  /// \see optimium::runtime::Device
  Result<Device> getDevice(PlatformKind Platform, DeviceKind Device,
                           int Index = 0,
                           const Capability *RequiredCapability = nullptr);

  /// Internal API.
  /// \param ID
  /// \return
  Result<Device> getDevice(DeviceID ID);

  /// Load a extension from given path.
  /// \param Path a path of a extension to load.
  /// \throw std::invalid_argument
  ///        thrown when \c Path is empty and/or invalid.
  /// \throw InvalidExtensionException
  ///        thrown when the extension is invalid.
  /// \throw ExtensionException
  ///        thrown when the extension does not caught exception and propagated
  ///        to the runtime.
  Result<void> loadExtension(const std::string &Path);

  /// Get current verbosity.
  /// \return a \c LogLevel represents current verbosity.
  [[nodiscard, deprecated("use LogSettings::getLogLevel() instead.")]] LogLevel
  getVerbosity() const;

  /// Update to new verbosity and get previous one.
  /// \param Level a \c LogLevel to change.
  /// \return a \c LogLevel represents previous verbosity.
  [[deprecated("use LogSettings::setLogLevel(LogLevel) instead.")]] LogLevel
  setVerbosity(LogLevel Level);

  /// Get a list of information of devices that are currently recognized and
  /// accessible from the runtime.
  /// \return a \c std::vector that contains \c DeviceInfo represents
  /// information of recognized devices.
  [[nodiscard]] std::vector<Device> getAvailableDevices() const;

  /// Get version of the runtime.
  /// \note Must not assume \c Context::getVersion() and
  /// \c OPTIMIUM_RT_CURRENT_VERSION are same; Header files and shared libraries
  /// may have different version.
  /// \return a \c VersionTuple represents current version of the runtime.
  [[nodiscard]] static VersionTuple getVersion();

  /// Get commit ID of the runtime.
  /// \note Must not assume \c Context::getCommitID() and
  /// \c OPTIMIUM_RT_GIT_COMMIT_ID are same; Header files and shared libraries
  /// may have different version.
  /// \return a \c std::string_view represents current commit ID of the runtime.
  [[nodiscard]] static std::string_view getCommitID();

  /// Create a context.
  /// \param Options
  /// \return
  [[nodiscard]] static Result<Context>
  create(const ContextOptions &Options = {});

private:
  explicit Context(detail::ContextDetail *Detail) : Detail(Detail) {}

  detail::ContextDetail *Detail = nullptr;
}; // end class Context
} // end namespace optimium::runtime

#endif // OPTIMIUM_RUNTIME_CONTEXT_H