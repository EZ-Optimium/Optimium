//===-- Any.h - Unified value list and dictionary. --------------*- C++ -*-===//
//
// This file is part of Optimium-Runtime. Confidential and proprietary.
//
// Copyright (c) 2022~2023 ENERZAi Corporation.
// All Rights Reserved.
//
//===----------------------------------------------------------------------===//
///
/// \file
/// This file contains the definition of \c Any class, which represents "any"
/// (in precise: int, float, bool, string, Any of std::vector, Any of
/// std::unordered_map) value.
///
//===----------------------------------------------------------------------===//
#ifndef OPTIMIUM_RUNTIME_UTILS_ANY_H
#define OPTIMIUM_RUNTIME_UTILS_ANY_H

#include "Optimium/Runtime/Export.h"
#include "Optimium/Runtime/Utils/TypeTraits.h"

#include <cassert>
#include <optional>
#include <string>
#include <string_view>
#include <unordered_map>
#include <utility>
#include <vector>

namespace optimium::runtime {
class Any;
class Dict;
class List;

namespace detail {
template <typename Type>
constexpr bool IsNotAny = !Is<Type, Any>;

template <typename Type>
constexpr bool ExactWithSupportedType =
    IsOneOf<Type, int64_t, uint64_t, double, bool, std::string, List, Dict>;

template <typename Type>
constexpr bool IsString =
    IsOneOf<Type, std::string, std::string_view, const char *>;

/// Represents type of \c Value union.
enum class ValueType {
  /// Unsupported type
  Unknown,

  /// nullptr
  None,

  /// int64_t
  SignedInt,

  /// uint64_t
  UnsignedInt,

  /// double
  Float,

  /// bool
  Boolean,

  /// std::string
  String,

  /// std::vector
  List,

  /// std::unordered_map
  Dict
}; // end enum Type

union Value {
  void *Raw = nullptr;
  int64_t SignedInt;
  uint64_t UnsignedInt;
  double Float;
  bool Boolean;
  std::string *String;
  List *Lst;
  Dict *Dct;

  OPTIMIUM_RT_EXPORT void destruct(detail::ValueType Type);

  Value() = default;

  Value(Value &&Other) noexcept : Raw(Other.Raw) {}

  Value &operator=(Value &&Other) noexcept {
    Raw = Other.Raw;
    Other.Raw = nullptr;
    return *this;
  }
}; // end union Value

// Should be equal to size of largest member - int64_t
static_assert(sizeof(Value) == sizeof(int64_t));

template <typename T>
[[nodiscard]] constexpr ValueType toType() {
  using DecayT = std::decay_t<T>;

  if constexpr (std::is_same_v<DecayT, std::nullptr_t>)
    return ValueType::None;

  if constexpr (IsSignedInt<DecayT>)
    return ValueType::SignedInt;

  if constexpr (IsUnsignedInt<DecayT>)
    return ValueType::UnsignedInt;

  if constexpr (IsFloat<DecayT>)
    return ValueType::Float;

  if constexpr (std::is_same_v<bool, DecayT>)
    return ValueType::Boolean;

  if constexpr (IsString<DecayT>)
    return ValueType::String;

  if constexpr (std::is_same_v<List, DecayT>)
    return ValueType::List;

  if constexpr (std::is_same_v<Dict, DecayT>)
    return ValueType::Dict;

  return ValueType::Unknown;
}

template <typename T>
Value make_value(T &&V);

OPTIMIUM_RT_EXPORT Value copy(ValueType, const Value &);

template <typename T>
constexpr auto &ref(Value &V) {
  constexpr auto Type = toType<T>();
  static_assert(Type != ValueType::Unknown && Type != ValueType::None,
                "cannot get reference of unknown or none type.");
  if constexpr (Type == ValueType::SignedInt)
    return V.SignedInt;

  if constexpr (Type == ValueType::UnsignedInt)
    return V.UnsignedInt;

  if constexpr (Type == ValueType::Float)
    return V.Float;

  if constexpr (Type == ValueType::Boolean)
    return V.Boolean;

  if constexpr (Type == ValueType::String)
    return *V.String;

  if constexpr (Type == ValueType::List)
    return *V.Lst;

  if constexpr (Type == ValueType::Dict)
    return *V.Dct;
}

template <typename T>
constexpr auto &ref(const Value &V) {
  constexpr auto Type = toType<T>();
  static_assert(Type != ValueType::Unknown && Type != ValueType::None,
                "cannot get reference of unknown or none type.");
  if constexpr (Type == ValueType::SignedInt)
    return V.SignedInt;

  if constexpr (Type == ValueType::UnsignedInt)
    return V.UnsignedInt;

  if constexpr (Type == ValueType::Float)
    return V.Float;

  if constexpr (Type == ValueType::Boolean)
    return V.Boolean;

  if constexpr (Type == ValueType::String)
    return *V.String;

  if constexpr (Type == ValueType::List)
    return *V.Lst;

  if constexpr (Type == ValueType::Dict)
    return *V.Dct;
}
} // end namespace detail

/// Represents any value in single type.
class OPTIMIUM_RT_API Any final {
private:
  detail::ValueType Type = detail::ValueType::None;
  detail::Value Val;

public:
  Any() = default;

  ~Any() noexcept { Val.destruct(Type); }

  Any(const Any &Other)
      : Type(Other.Type), Val(detail::copy(Other.Type, Other.Val)) {}

  Any(Any &&Other) noexcept : Type(Other.Type), Val(std::move(Other.Val)) {
    Other.Type = detail::ValueType::None;
  }

  template <typename T, std::enable_if_t<detail::IsNotAny<T>, int> = 0>
  explicit Any(T &&V)
      : Type(detail::toType<T>()),
        Val(detail::make_value<T &&>(std::forward<T &&>(V))) {}

  template <typename T, std::enable_if_t<detail::IsNotAny<T>, int> = 0>
  Any &operator=(T &&V) {
    Val.destruct(Type);

    Type = detail::toType<T>();
    Val = detail::make_value(std::forward<T &&>(V));
    return *this;
  }

  Any &operator=(const Any &Other) {
    Val.destruct(Type);

    Val = detail::copy(Other.Type, Other.Val);
    Type = Other.Type;

    return *this;
  }

  Any &operator=(Any &&Other) noexcept {
    Val.destruct(Type);

    Val = std::move(Other.Val);
    Type = Other.Type;

    return *this;
  }

  /// Get reference of the value.
  /// \tparam T type of the value. Must be one of \c int64_t, \c double,
  ///           \c bool, \c std::string, \c List or \c Dict.
  /// \return Reference of the value typed in \c T.
  template <typename T>
  T &ref() {
    static_assert(detail::ExactWithSupportedType<T>,
                  "must be exact type rather than derived type.");
    assert(detail::toType<T>() == Type && "not an exact type.");

    return detail::ref<T>(Val);
  }

  template <typename T>
  const T &ref() const {
    static_assert(detail::ExactWithSupportedType<T>,
                  "must be exact type rather than derived type.");
    assert(detail::toType<T>() == Type && "not an exact type.");

    return detail::ref<T>(Val);
  }

  /// Get value as \c T.
  /// \tparam T type of the value.
  /// \return the value typed in \c T.
  /// \throw std::logic_error Thrown when actual type of the value does not
  ///                         equal or convertible to expected type \c T.
  template <typename T>
  T as() const {
    constexpr auto Expected = detail::toType<T>();
    static_assert(Expected != detail::ValueType::Unknown,
                  "unsupported type for Any.");
    assert(Expected == Type && "type mismatch.");

    return detail::ref<T>(const_cast<Any *>(this)->Val);
  }

  /// Check that the value is convertible to \c T.
  /// \tparam T expected type of the value.
  /// \return \c true if equal or convertible to, otherwise \c false.
  template <typename T>
  [[nodiscard]] bool is() const {
    constexpr auto Expected = detail::toType<T>();
    static_assert(Expected != detail::ValueType::Unknown,
                  "unsupported type for Any.");

    return Expected == Type;
  }

  /// Check that the value contains anything (nullptr).
  /// \return \c true if the value empty, otherwise \c false.
  [[nodiscard]] bool empty() const { return Type == detail::ValueType::None; }

  bool operator!() const { return empty(); }
}; // end class Any

/// Convert \c Any to readable string.
/// \param Value value for convert to string.
/// \return a string that represents corresponding \c Any.
OPTIMIUM_RT_API std::string toString(const Any &Value);

/// Represents dictionary(or map) of \c Any, paired with string.
class Dict final : public std::unordered_map<std::string, Any> {
  using super = std::unordered_map<std::string, Any>;

public:
  using super::super;

  /// Get a value with given key.
  /// \param Key a string associated with the value.
  /// \return \c std::optional that can be empty if the value was not found.
  std::optional<Any> get(const std::string &Key) const {
    auto It = super::find(Key);
    return (It == super::end()) ? std::nullopt : std::make_optional(It->second);
  }

  /// Get a value with given key and type.
  /// \tparam T expected type of the value.
  /// \param Key a string associated with the value.
  /// \return \c std::optional that can be empty if the value was not found.
  template <typename T>
  std::optional<T> get(const std::string &Key) const {
    auto It = super::find(Key);

    if (It != super::end() && It->second.template is<T>())
      return It->second.template as<T>();
    else
      return std::nullopt;
  }
}; // end class Dict

/// Convert \c Dict to readable string.
/// \param Value value for convert to string.
/// \return a string that represents corresponding \c Dict.
OPTIMIUM_RT_API std::string toString(const Dict &Value);

/// Represents list(or vector) of \c Any.
class List final : public std::vector<Any> {
  using super = std::vector<Any>;

public:
  using super::super;
}; // end class List

/// Convert \c List to readable string.
/// \param Value value for convert to string.
/// \return a string that represents corresponding \c List.
OPTIMIUM_RT_API std::string toString(const List &Value);

namespace detail {
template <typename T>
Value make_value(T &&V) {
  constexpr auto Type = detail::toType<T>();
  static_assert(Type != detail::ValueType::Unknown,
                "unsupported type for Any.");

  Value Val;
  if constexpr (Type == ValueType::SignedInt)
    Val.SignedInt = V;

  if constexpr (Type == ValueType::UnsignedInt)
    Val.UnsignedInt = V;

  if constexpr (Type == ValueType::Float)
    Val.Float = V;

  if constexpr (Type == ValueType::Boolean)
    Val.Boolean = V;

  if constexpr (Type == ValueType::String)
    Val.String = new std::string(std::forward<T &&>(V));

  if constexpr (Type == ValueType::List)
    Val.Lst = new List(std::forward<T &&>(V));

  if constexpr (Type == ValueType::Dict)
    Val.Dct = new Dict(std::forward<T &&>(V));

  return Val;
}
} // namespace detail
} // end namespace optimium::runtime

#endif // OPTIMIUM_RUNTIME_UTILS_ANY_H