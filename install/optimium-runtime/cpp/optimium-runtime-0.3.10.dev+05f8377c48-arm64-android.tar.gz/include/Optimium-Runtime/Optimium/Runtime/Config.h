//===-- Config.h - Represents failable result -------------------*- C++ -*-===//
//
// This file is part of Optimium-Runtime. Confidential and proprietary.
//
// Copyright (c) 2022~2024 ENERZAi Corporation.
// All Rights Reserved.
//
//===----------------------------------------------------------------------===//
///
/// Defines constant values ​​used globally in Optimium Runtime.
///
//===----------------------------------------------------------------------===//
#ifndef OPTIMIUM_RUNTIME_CONFIG_H
#define OPTIMIUM_RUNTIME_CONFIG_H

namespace optimium::runtime {

// Default nice value indicating that the value has not been set yet.
// As a result, the nice value will not be applied if it matches this default.
inline constexpr int UnsetNice = -99;
inline constexpr int MinimumNice = -20;
inline constexpr int MaximumNice = 19;

} // namespace optimium::runtime

#endif // OPTIMIUM_RUNTIME_CONFIG_H