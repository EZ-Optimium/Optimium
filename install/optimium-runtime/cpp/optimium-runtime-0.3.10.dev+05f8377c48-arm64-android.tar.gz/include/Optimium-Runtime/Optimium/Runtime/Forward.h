//===-- Forward.h - Forward declarations ------------------------*- C++ -*-===//
//
// This file is part of Optimium-Runtime. Confidential and proprietary.
//
// Copyright (c) 2022~2023 ENERZAi Corporation.
// All Rights Reserved.
//
//===----------------------------------------------------------------------===//
///
/// \file
/// This file contains forward declarations of classes and enumerations in
/// public API set of Optima Runtime API.
///
//===----------------------------------------------------------------------===//
#ifndef OPTIMIUM_RUNTIME_FORWARD_H
#define OPTIMIUM_RUNTIME_FORWARD_H

#include <cstdint>
#include <tuple>

namespace optimium::runtime {
// Defined in Optimium/Runtime/Capability.h
class Capability;
class X86Capability;
enum class X86FeatureKind;
class ARMCapability;
enum class ARMFeatureKind;
class SPIRVCapability;
enum class SPIRVFeatureKind;
enum class SPIRVTarget;
class CUDACapability;

// Defined in Optimium/Runtime/Context.h
class Context;

// Defined in Optimium/Runtime/ContextOptions.h
struct ContextOptions;

// Defined in Optimium/Runtime/DeviceKind.h
enum class DeviceKind;

// Defined in Optimium/Runtime/Device.h
class Device;
using DeviceID = uint32_t;

// Defined in Optimium/Runtime/Host.h
struct HostInfo;
enum class ConnectionMethod;

// Defined in Optimium/Runtime/InferRequest.h
enum class InferStatus;
class InferRequest;

// Defined in Optimium/Runtime/Model.h
class Model;
struct ModelOptions;

// Defined in Optimium/Runtime/Platform.h
enum class PlatformKind;

// Defined in Optimium/Runtime/Profile.h
enum class ProfileKind;
struct ProfileData;

// Defined in Optimium/Runtime/RemoteContext.h
class RemoteContext;

// Defined in Optimium/Runtime/Result.h
enum class Status : uint32_t;
class Error;
class Ok;
template <typename>
class Result;

// Defined in Optimium/Runtime/Shape.h
class Shape;

// Defined in Optimium/Runtime/Tensor.h
class Tensor;

// Defined in Optimium/Runtime/TensorInfo.h
struct QuantizationParams;
class QuantizationScheme;
struct TensorInfo;

// Defined in Optimium/Runtime/Type.h
enum class ElementType;

// Defined in Optimium/Runtime/Version.h
using VersionTuple = std::tuple<int, int, int>;

// Defined in Optimium/Runtime/Logging/LogLevel.h
enum class LogLevel;

// Defined in Optimium/Runtime/Logging/LogSettings.h
class LogSettings;

// Defined in Optimium/Runtime/Types/BFloat16.h
class bfloat16;

// Defined in Optimium/Runtime/Types/Float16.h
class float16;
using half = float16;

// Defined in Optimium/Runtime/Types/QFloat.h
class qsfloat8;
class qufloat8;
class qsfloat16;
class qufloat16;

// Defined in Optimium/Runtime/Types/TFloat32.h
class tfloat32;

// Defined in Optimium/Runtime/Utils/Any.h
class Any;
class Dict;
class List;
} // end namespace optimium::runtime

#endif // OPTIMIUM_RUNTIME_FORWARD_H