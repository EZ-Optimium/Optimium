//===-- Assert.h - Assertion functions --------------------------*- C++ -*-===//
//
// This file is part of Optimium-Runtime. Confidential and proprietary.
//
// Copyright (c) 2022~2023 ENERZAi Corporation.
// All Rights Reserved.
//
//===----------------------------------------------------------------------===//
///
/// \file
/// This file contains macro functions for assertions.
///
//===----------------------------------------------------------------------===//
#ifndef OPTIMIUM_RUNTIME_ASSERT_H
#define OPTIMIUM_RUNTIME_ASSERT_H

#include <cassert>

#define NEVER_BE_NULL(Expr) (assert((Expr) != nullptr && "never be null."))

#define NEVER_BE_INVALID_STRING(String)                                        \
  (((String) != nullptr) && ((String)[0] != '\0') && "string must be valid.")

#define MUST_BE_NULL(Expr) (assert((Expr) == nullptr && "must be null."))

#define UNREACHABLE(Message) (assert(!"not reachable; " Message))

#endif // OPTIMIUM_RUNTIME_ASSERT_H