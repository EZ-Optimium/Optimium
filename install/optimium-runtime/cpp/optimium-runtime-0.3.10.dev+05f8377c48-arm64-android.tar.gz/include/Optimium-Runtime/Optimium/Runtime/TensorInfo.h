//===-- TensorInfo.h -  -*- C++ -*-===//
//
// This file is part of Optimium-Runtime. Confidential and proprietary.
//
// Copyright (c) 2022~2023 ENERZAi Corporation.
// All Rights Reserved.
//
//===----------------------------------------------------------------------===//
///
/// \file
///
///
//===----------------------------------------------------------------------===//
#ifndef OPTIMIUM_RUNTIME_TENSOR_INFO_H
#define OPTIMIUM_RUNTIME_TENSOR_INFO_H

#include "Optimium/Runtime/Export.h"
#include "Optimium/Runtime/Shape.h"
#include "Optimium/Runtime/Type.h"
#include "Optimium/Runtime/Utils/NonCopyable.h"

#include <optional>
#include <string>
#include <string_view>
#include <vector>

namespace optimium::runtime {
/// Represent parameters for map between quantized values and floating-point
/// values
struct QuantizationParams final {
  OPTIMIUM_RT_DEFAULT_COPYABLE(QuantizationParams);
  OPTIMIUM_RT_DEFAULT_MOVABLE(QuantizationParams);

  /// Floating-point value for minimum value that can be expressed from
  /// quantized value.
  float Min = 0.0f;

  /// Floating-point value for maximum value that can be expressed from
  /// quantized value.
  float Max = 0.0f;

  /// Floating-point value for single step (1) in quantized value.
  float Scale = 0.0f;

  /// Integral value for what is '0' for quantized value.
  /// \c ZeroPoint == 0 if symmetric quantization is used,
  /// \c ZeroPoint != 0 if asymmetric quantization is used.
  int32_t ZeroPoint = 0;

  QuantizationParams() = default;

  QuantizationParams(float Min, float Max, float Scale, int32_t ZeroPoint)
      : Min(Min), Max(Max), Scale(Scale), ZeroPoint(ZeroPoint) {}

  /// Convert \c QuantizationParams to readable string.
  /// \return a string that represents corresponding \c QuantizationParams.
  OPTIMIUM_RT_API std::string toString() const;
}; // end struct QuantizedParams

///
class QuantizationScheme final {
public:
  QuantizationScheme(std::vector<QuantizationParams> Params, int Axis)
      : Params(std::move(Params)), Axis(Axis) {}

  explicit QuantizationScheme(QuantizationParams Params)
      : QuantizationScheme({Params}, -1) {}

  OPTIMIUM_RT_DEFAULT_COPYABLE(QuantizationScheme)
  OPTIMIUM_RT_DEFAULT_MOVABLE(QuantizationScheme)

  /// Test the tensor is per-channel quantized.
  /// \return \c true if the tensor is per-channel quantized,
  ///         otherwise \c false.
  [[nodiscard]] bool isPerChannel() const { return Axis >= 0; }

  /// Test the tensor is per-tensor quantized.
  /// \return \c true if the tensor is per-tensor quantized,
  ///         otherwise \c false.
  [[nodiscard]] bool isPerTensor() const { return !isPerChannel(); }

  /// Get quantization parameters for this tensor.
  /// \param Channel index to get quantization parameters.
  ///        It is undefined behavior when
  ///        <code>isPerTensor() && Channel != 0</code> or
  ///        <code>isPerChannel() && Channel >= Shape.getDimensionSize()</code>
  /// \return
  [[nodiscard]] const QuantizationParams &getParams(int Channel = 0) const {
    return Params.at(Channel);
  }

  /// Get dimension on which per-channel quantization is applied.
  /// Returns \c -1 if the tensor is per-tensor quantized.
  /// \return dimension on which per-channel quantization is applied.
  [[nodiscard]] int getAxis() const { return Axis; }

  /// Get count of channels. It is exposed for internal usage.
  /// Users are encouraged to use <code>Shape::getDimensionCount()</code>
  /// rather than this.
  /// \return ...
  [[nodiscard]] size_t getChannelCount() const { return Params.size(); }

  /// Convert \c QuantizationScheme to readable string.
  /// \return a string that represents corresponding \c QuantizationScheme.
  OPTIMIUM_RT_API std::string toString() const;

private:
  std::vector<QuantizationParams> Params;
  int Axis = -1;
}; // end class QuantizationScheme

/// Represents information of the tensor.
struct TensorInfo {
  OPTIMIUM_RT_DEFAULT_COPYABLE(TensorInfo);
  OPTIMIUM_RT_DEFAULT_MOVABLE(TensorInfo);

  /// Shape of the tensor.
  Shape TensorShape{};

  /// Alignment of the tensor that the device requires.
  uint32_t Alignment = 0;

  /// Type of the tensor
  ElementType TensorType = ElementType::F32;

  /// Name of the tensor.
  std::string TensorName{};

  /// Padding for the tensor.
  uint32_t Padding = 0;

  ///
  std::optional<QuantizationScheme> Scheme;

  TensorInfo() = default;

  TensorInfo(Shape Shape_, uint32_t Alignment, ElementType Type,
             std::string Name, uint32_t Padding)
      : TensorShape(Shape_), Alignment(Alignment), TensorType(Type),
        TensorName(std::move(Name)), Padding(Padding) {}

  /// Convert \c TensorInfo to readable string.
  /// \param Value value for convert to string.
  /// \return a string that represents corresponding \c TensorInfo.
  OPTIMIUM_RT_API std::string toString() const;
}; // end struct TensorInfo

///
/// \param Info
/// \return
inline size_t getTensorSize(const TensorInfo &Info) {
  auto Count = Info.TensorShape.getTotalElementCount();
  return Count * getSizeOfElement(Info.TensorType);
}
} // end namespace optimium::runtime

#endif // OPTIMIUM_RUNTIME_TENSOR_INFO_H