//===-- Export.h - Export macros --------------------------------*- C++ -*-===//
//
// This file is part of Optimium-Runtime. Confidential and proprietary.
//
// Copyright (c) 2022~2023 ENERZAi Corporation.
// All Rights Reserved.
//
//===----------------------------------------------------------------------===//
///
/// \file This file contains macro definitions for entrypoint or API marker.
///
//===----------------------------------------------------------------------===//
#ifndef OPTIMIUM_RUNTIME_EXPORT_H
#define OPTIMIUM_RUNTIME_EXPORT_H

#define OPTIMIUM_RT_EXPORT __attribute__((visibility("default")))
#define OPTIMIUM_RT_API __attribute__((visibility("default")))
#define OPTIMIUM_RT_ENTRYPOINT extern "C" OPTIMIUM_RT_EXPORT
#define OPTIMIUM_RT_C_API extern "C" OPTIMIUM_RT_EXPORT

#endif // OPTIMIUM_RUNTIME_EXPORT_H