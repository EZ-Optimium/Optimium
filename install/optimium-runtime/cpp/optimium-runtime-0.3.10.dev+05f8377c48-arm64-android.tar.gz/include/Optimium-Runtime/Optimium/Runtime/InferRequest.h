//===-- InferRequest.h - Represent single inference -------------*- C++ -*-===//
//
// This file is part of Optimium-Runtime. Confidential and proprietary.
//
// Copyright (c) 2022~2023 ENERZAi Corporation.
// All Rights Reserved.
//
//===----------------------------------------------------------------------===//
///
/// \file This file contains definition of InferRequest class.
///
//===----------------------------------------------------------------------===//
#ifndef OPTIMIUM_RUNTIME_INFER_REQUEST_H
#define OPTIMIUM_RUNTIME_INFER_REQUEST_H

#include "Optimium/Runtime/Assert.h"
#include "Optimium/Runtime/Export.h"
#include "Optimium/Runtime/Utils/NonCopyable.h"

#include <chrono>
#include <cstdint>
#include <functional>
#include <limits>
#include <string>
#include <string_view>
#include <vector>

namespace optimium::runtime {
class Tensor;         // Defined in Optimium/Runtime/Tensor.h
struct ProfileData;   // Defined in Optimium/Runtime/Profile.h
struct InferenceInfo; // Defined in Optimium/Runtime/InferRequest.h

template <typename>
class Result;

namespace detail {
struct ModelDetail;
} // end namespace detail

// clang-format off
#define OPTIMIUM_RT_INFER_STATUS_ENUM(Op) \
  Op(Idle) \
  Op(Running) \
  Op(Finished) \
  Op(Canceled) \
  Op(Fault)
// clang-format on

/// Represents status of the request.
enum class InferStatus {
/// \var InferStatus::Idle
///      Represents state that the inference is ready to run.
/// \var InferStatus::Running
///      Represents state that the inference currently running.
/// \var InferStatus::Finished
///      Represents state that the inference was finished without error.
/// \var InferStatus::Canceled
///      Represents state that the inference was canceled.
/// \var InferStatus::Fault
///      Represents state that the inference was finished with error.

#define OP(Value) Value,
  OPTIMIUM_RT_INFER_STATUS_ENUM(OP)
#undef OP
      Last = Fault
}; // end enum InferStatus

/// Convert \c InferStatus to readable string.
/// \param Value value for convert to string.
/// \return a string that represents corresponding \c InferStatus.
OPTIMIUM_RT_API std::string_view toString(InferStatus Value);

/// Represents callback function that is called when the inference is
/// finished successfully or finished with error.
/// If the inference is finished and \c Result.ok() == true,
/// it means the inference is finished without error. Otherwise,
/// \c Result.error() represents an error during inference.
using InferRequestCallback = std::function<void(const Result<void> &Result)>;

/// Represents single inference of the model.
/// Users can create multiple of \c InferRequest to achieve more throughput.
class OPTIMIUM_RT_API InferRequest final {
public:
  OPTIMIUM_RT_NON_COPYABLE(InferRequest)

  static constexpr auto kInvalidID = std::numeric_limits<uint32_t>::max();

  InferRequest() = default;

  ~InferRequest() { clear(); }

  InferRequest(InferRequest &&Other) noexcept
      : Model(Other.Model), ID(Other.ID) {
    Other.Model = nullptr;
    Other.ID = kInvalidID;
  }

  InferRequest &operator=(InferRequest &&Other) noexcept {
    clear();

    std::swap(Model, Other.Model);
    std::swap(ID, Other.ID);

    return *this;
  }

  /// Get input tensor by its index.
  /// \param Index index of input tensor.
  /// \return a \c Tensor.
  [[nodiscard]] Result<Tensor> getInputTensor(int Index = 0);

  /// Get input tensor by its name.
  /// \param Index name of input tensor.
  /// \return a \c Tensor.
  [[nodiscard]] Result<Tensor> getInputTensor(const std::string &Name);

  /// Get count of input tensors.
  /// \return an integral value that represents count of input tensors.
  [[nodiscard]] int getInputTensorCount() const;

  /// Get list of input tensors.
  /// \return a \c std::vector of input tensors.
  [[nodiscard]] Result<std::vector<Tensor>> getInputTensors();

  /// Get output tensor by its index.
  /// \param Index index of output tensor.
  /// \return a \c Tensor.
  [[nodiscard]] Result<Tensor> getOutputTensor(int Index = 0);

  /// Get output tensor by its name.
  /// \param Name name of output tensor.
  /// \return a \c Tensor.
  [[nodiscard]] Result<Tensor> getOutputTensor(const std::string &Name);

  /// Get count of output tensors.
  /// \return an integral value that represents count of output tensors.
  [[nodiscard]] int getOutputTensorCount() const;

  /// Get list of output tensors.
  /// \return a \c std::vector of output tensors.
  [[nodiscard]] Result<std::vector<Tensor>> getOutputTensors();

  /// Get a tensor by its index.
  /// \param Index index of the tensor.
  /// \return a \c Tensor.
  [[nodiscard]] Result<Tensor> getTensor(int Index);

  /// Get a tensor by its name.
  /// \param Name name of the tensor.
  /// \return a \c Tensor.
  [[nodiscard]] Result<Tensor> getTensor(const std::string &Name);

  /// Get list of all tensors.
  /// \return a \c std::vector of all tensors in the model.
  [[nodiscard]] Result<std::vector<Tensor>> getTensors();

  /// Get count of total tensors.
  /// \return an integral value that represents count of all tensors.
  [[nodiscard]] int getTensorCount() const;

  /// Set callback for this \c InferRequest. Callback is called when
  /// inference is ended.
  /// \param Callback callback function.
  /// \see InferRequestCallback
  Result<void> setCallback(InferRequestCallback Callback);

  /// Run inference.
  Result<void> infer();

  /// Wait until the inference finished.
  /// \param Timeout maximum time to wait this event.
  ///                Default is waiting endlessly.
  /// \return \c true if the inference is finished before timeout, otherwise
  ///         \c false.
  Result<bool>
  wait(std::chrono::milliseconds Timeout = std::chrono::milliseconds(0));

  /// Get status of the inference.
  /// \return an \c InferStatus enumeration that represents current state of
  ///         the inference.
  /// \see InferStatus
  [[nodiscard]] InferStatus getStatus() const;

  /// Cancel the inference.
  Result<void> cancel();

  /// Run inference with profile mode.
  /// \note Model should be loaded with \c EnableProfile=true.
  /// \param InferenceInfo
  Result<void> startProfile(const InferenceInfo &Info);

  /// Get raw profile data.
  /// \return \c std::vector of \c ProfileData that captured from just
  ///         previous inference.
  [[nodiscard]] Result<std::vector<ProfileData>> getProfileData() const;

private:
  friend class Model;

  void clear();

  InferRequest(detail::ModelDetail *Model, uint32_t ID) : Model(Model), ID(ID) {
    NEVER_BE_NULL(Model);
  }

  detail::ModelDetail *Model = nullptr;
  uint32_t ID = kInvalidID;
}; // end class InferRequest

struct InferenceInfo {
  int RepeatCount{0};
  int WarmUpCount{0};
  float Threshold{0};
  int EarlyStop{0};
  float MinWarmUpSeconds{0};

  InferenceInfo(int RepeatCount) : RepeatCount(RepeatCount) {}

  InferenceInfo(int RepeatCount, int WarmUpCount, float Threshold,
                int EarlyStop, float MinWarmUpSeconds)
      : RepeatCount(RepeatCount), WarmUpCount(WarmUpCount),
        Threshold(Threshold), EarlyStop(EarlyStop),
        MinWarmUpSeconds(MinWarmUpSeconds) {}
}; // end struct InferenceInfo
} // namespace optimium::runtime

#endif // OPTIMIUM_RUNTIME_INFER_REQUEST_H
