//===-- TFloat32.h - Software-implemented tensor float-32 -------*- C++ -*-===//
//
// This file is part of Optimium-Runtime. Confidential and proprietary.
//
// Copyright (c) 2022~2023 ENERZAi Corporation.
// All Rights Reserved.
//
//===----------------------------------------------------------------------===//
///
/// \file
/// This file contains definition of \c tfloat32 (a.k.a TensorFloat-32).
///
//===----------------------------------------------------------------------===//
#ifndef OPTIMIUM_RUNTIME_TYPES_TFLOAT32_H
#define OPTIMIUM_RUNTIME_TYPES_TFLOAT32_H

#include "Optimium/Runtime/Export.h"

#include <cstdint>
#include <limits>

namespace optimium::runtime {
/// Software-implemented TensorFloat-32.
/// \see
/// https://blogs.nvidia.com/blog/2020/05/14/tensorfloat-32-precision-format/
class OPTIMIUM_RT_API tfloat32 final {
  uint32_t Raw = 0;

public:
  static constexpr struct {
  } raw{};

  constexpr tfloat32() = default;

  constexpr tfloat32(decltype(raw), uint32_t Raw) : Raw(Raw) {}

  /* implicit */
  constexpr tfloat32(float Value) : Raw(convert(Value)) {}

  /* implicit */
  constexpr operator float() const { return convert(Raw); }

  constexpr bool operator==(const tfloat32 &Other) const {
    return float(*this) == float(Other);
  }

  constexpr bool operator!=(const tfloat32 &Other) const {
    return !(operator==(Other));
  }

  constexpr bool operator<(const tfloat32 &Other) const {
    return float(*this) < float(Other);
  }

  constexpr bool operator>(const tfloat32 &Other) const {
    return float(*this) > float(Other);
  }

  constexpr bool operator<=(const tfloat32 &Other) const {
    return !(operator>(Other));
  }

  constexpr bool operator>=(const tfloat32 &Other) const {
    return !(operator<(Other));
  }

  constexpr tfloat32 operator+(tfloat32 Other) const {
    return float(*this) + float(Other);
  }

  constexpr tfloat32 operator-(tfloat32 Other) const {
    return float(*this) - float(Other);
  }

  constexpr tfloat32 operator*(tfloat32 Other) const {
    return float(*this) * float(Other);
  }

  constexpr tfloat32 operator/(tfloat32 Other) const {
    return float(*this) / float(Other);
  }

  constexpr tfloat32 &operator++() {
    (*this) += 1.0f;
    return *this;
  }

  constexpr tfloat32 operator++(int) {
    auto Old = *this;
    operator++();
    return Old;
  }

  constexpr tfloat32 &operator--() {
    (*this) -= 1.0f;
    return *this;
  }

  constexpr tfloat32 operator--(int) {
    auto Old = *this;
    operator--();
    return Old;
  }

  constexpr tfloat32 &operator+=(tfloat32 Other) {
    (*this) = (*this) + Other;
    return *this;
  }

  constexpr tfloat32 &operator-=(tfloat32 Other) {
    (*this) = (*this) - Other;
    return *this;
  }

  constexpr tfloat32 &operator*=(tfloat32 Other) {
    (*this) = (*this) * Other;
    return *this;
  }

  constexpr tfloat32 &operator/=(tfloat32 Other) {
    (*this) = (*this) / Other;
    return *this;
  }

  constexpr tfloat32 operator-() const {
    uint32_t New = Raw ^ kSignMask;
    return {raw, New};
  }

  constexpr tfloat32 operator+() const { return *this; }

private:
  static constexpr uint32_t kMask = 0xFFFFE000u;
  static constexpr uint32_t kSignMask = 0x80000000u;

  inline static constexpr uint32_t convert(float Value) {
    return bit_cast<uint32_t>(Value) & kMask;
  }

  inline static constexpr float convert(uint32_t Value) {
    return bit_cast<float>(Value & kMask);
  }
}; // end class tfloat32

namespace literals {
inline tfloat32 operator""_tf(long double Float) { return {float(Float)}; }
inline tfloat32 operator""_tf(unsigned long long int Int) {
  return {float(Int)};
}
} // namespace literals
} // end namespace optimium::runtime

template <>
class std::numeric_limits<optimium::runtime::tfloat32> {
  using tfloat32 = optimium::runtime::tfloat32;

public:
  static constexpr bool is_specialized = true;
  static constexpr bool is_signed = true;
  static constexpr bool is_integer = false;
  static constexpr bool is_exact = false;
  static constexpr bool has_infinity = true;
  static constexpr bool has_quiet_NaN = true;
  static constexpr bool has_signaling_NaN = true;
  static constexpr std::float_denorm_style has_denorm = std::denorm_present;
  static constexpr bool has_denorm_loss = true;
  static constexpr std::float_round_style round_style = std::round_to_nearest;
  static constexpr bool is_iec559 = true;
  static constexpr bool is_bounded = true;
  static constexpr bool is_modulo = false;
  static constexpr int digits = 11;
  static constexpr int digits10 = 3;
  static constexpr int max_digits10 = 5;
  static constexpr int radix = 2;
  static constexpr int min_exponent = -13;
  static constexpr int min_exponent10 = -4;
  static constexpr int max_exponent = 16;
  static constexpr int max_exponent10 = 4;
  static constexpr tfloat32 min() noexcept {
    // 1.0p-126
    return {tfloat32::raw, 0b0'00000001'0000000000'0000000000000u};
  }
  static constexpr tfloat32 lowest() noexcept {
    // -1.FFCp-127
    return {tfloat32::raw, 0b1'11111110'1111111111'0000000000000u};
  }
  static constexpr tfloat32 max() noexcept {
    // 1.FFCp+127
    return {tfloat32::raw, 0b0'11111110'1111111111'0000000000000u};
  }
  static constexpr tfloat32 epsilon() noexcept {
    // 1.0p-10
    return {tfloat32::raw, 0b0'01110101'0000000000'0000000000000u};
  }
  static constexpr tfloat32 round_error() noexcept {
    // 1.0p-1
    return {tfloat32::raw, 0b0'01111110'0000000000'0000000000000u};
  }
  static constexpr tfloat32 infinity() noexcept {
    return {tfloat32::raw, 0b0'11111111'0000000000'0000000000000u};
  }
  static constexpr tfloat32 quiet_NaN() noexcept {
    return {tfloat32::raw, 0b0'11111111'1111111111'0000000000000u};
  }
  static constexpr tfloat32 signaling_NaN() noexcept {
    return {tfloat32::raw, 0b0'11111111'0111111111'0000000000000u};
  }
  static constexpr tfloat32 denorm_min() noexcept {
    // 1.0p-138
    return {tfloat32::raw, 0b0'00000000'0000000001'0000000000000u};
  }
}; // end class std::numeric_limits<optimium::runtime::tfloat32>

#endif // OPTIMIUM_RUNTIME_TYPES_TFLOAT32_H