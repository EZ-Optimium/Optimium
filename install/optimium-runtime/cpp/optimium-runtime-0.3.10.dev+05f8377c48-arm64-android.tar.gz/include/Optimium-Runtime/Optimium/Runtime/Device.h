//===-- Device.h - Provide device information -------------------*- C++ -*-===//
//
// This file is part of Optimium-Runtime. Confidential and proprietary.
//
// Copyright (c) 2022~2023 ENERZAi Corporation.
// All Rights Reserved.
//
//===----------------------------------------------------------------------===//
///
/// \file
/// This file contains definition of \c Device class, which represents
/// an device executing the model.
///
//===----------------------------------------------------------------------===//
#ifndef OPTIMIUM_RUNTIME_DEVICE_H
#define OPTIMIUM_RUNTIME_DEVICE_H

#include "Optimium/Runtime/Assert.h"
#include "Optimium/Runtime/DeviceKind.h"
#include "Optimium/Runtime/Export.h"
#include "Optimium/Runtime/Result.h"
#include "Optimium/Runtime/Utils/Any.h"
#include "Optimium/Runtime/Utils/ArrayRef.h"
#include "Optimium/Runtime/Utils/NonCopyable.h"

#include <memory>
#include <string>

namespace optimium::runtime {
class Capability;        // Defined in Optimium/Runtime/Capability.h
class Context;           // Defined in Optimium/Runtime/Context.h
enum class PlatformKind; // Defined in Optimium/Runtime/Platform.h
struct HostInfo;         // Defined in Optimium/Runtime/Host.h
class RemoteContext;     // Defined in Optimium/Runtime/RemoteContext.h

class Session;

/// Unique ID to distinguish between devices in the runtime.
using DeviceID = uint32_t;

/// Represents invalid device.
constexpr DeviceID kInvalidDevice = DeviceID(-1);

/// Represents a device that executes the model.
class OPTIMIUM_RT_API Device final {
public:
  OPTIMIUM_RT_DEFAULT_MOVABLE(Device)
  OPTIMIUM_RT_DEFAULT_COPYABLE(Device)

  Device() = default;

  /// Exposed for internal usage. DO NOT USE IT.
  Device(DeviceID ID, Session &Owner) : ID(ID), Owner(&Owner) {}

  /// Get platform of the device.
  /// \return a \c PlatformKind that represents kind of the platform.
  [[nodiscard]] PlatformKind getPlatform() const;

  /// Get kind of the device.
  /// \return a \c DeviceKind that represents kind of the device.
  [[nodiscard]] DeviceKind getKind() const;

  /// Get name of the device.
  /// \return a string that represents name of the device.
  [[nodiscard]] std::string_view getName() const;

  /// Get ID of the device.
  /// \return a string that represents ID of the device.
  /// \note It may differ with \c ID argument from other member functions.
  [[nodiscard]] DeviceID getDeviceID() const;

  /// Check whether the device is come from remote host or not.
  /// \return \c true if the device is remote device, otherwise \c false.
  [[nodiscard]] bool isRemote() const;

  /// Get information of the host.
  /// \return reference of \c HostInfo that describes information of the host.
  [[nodiscard]] const HostInfo &getHostInfo() const;

  /// Get capability of the device. Can be \c VoidCapability if the device
  /// does not require specific capability.
  /// \return reference of \c Capability that represents capability of
  ///         the device.
  [[nodiscard]] const Capability &getCapability() const;

  /// Get session which owns this device.
  /// \warning This method is exposed for internal usage.
  /// \return reference of \c Session that owns this device.
  [[nodiscard]] Session &getOwner() const { return *Owner; }

  /// Get ID of the session which owns this device.
  /// \warning This method is exposed for internal usage.
  /// \return ID of the session that owns this device.
  [[nodiscard]] int getOwnerID() const;

  /// Get option value named \c Key.
  /// \param Key a string that represents the key of the option.
  /// \return optional of \c Any object.
  std::optional<Any> getOption(const std::string &Key) const {
    return Options.get(Key);
  }

  /// Update an option for the device.
  /// \param Key a string that represents the key of the option.
  /// \param Value an \c Any object that represents the value of the option.
  ///              May be \c nullptr (or empty) to remove the option.
  void setOption(const std::string &Key, Any Value) {
    if (Value.empty()) {
      auto It = Options.find(Key);
      Options.erase(It);
    } else {
      Options.insert_or_assign(Key, std::move(Value));
    }
  }

  void setOptions(Dict D) { Options = std::move(D); }

  /// Get set of options for the device.
  /// \return
  const Dict &getOptions() const { return Options; }

  /// Convert \c Device to readable string.
  /// \return a string that represents corresponding \c Device.
  [[nodiscard]] std::string toString() const;

  explicit operator bool() const { return ID != kInvalidDevice; }

  /// Convenient function for creating Native device.
  /// \param Context runtime context.
  /// \param Mode execution mode for CPU device.
  ///             Allowed values: PERFORMANCE, INTERMEDIATE, EFFICIENCY
  /// \return a \c Device that represents Native device.
  static Result<Device> native(Context &Context, std::string_view Mode = "");

  /// Convenient function for creating Vulkan device.
  /// \param Context runtime context.
  /// \param Index index of device to select.
  /// \return a \c Device that represents Vulkan device.
  static Result<Device> vulkan(Context &Context, int Index = 0);

  /// Convenient function for creating OpenCL device.
  /// \param Context runtime context.
  /// \param Index index of device to select.
  /// \return a \c Device that represents OpenCL device.
  static Result<Device> opencl(Context &Context, int Index = 0);

  /// Convenient function for creating CUDA device.
  /// \param Context runtime context.
  /// \param Index index of device to select.
  /// \return a \c Device that represents CUDA device.
  static Result<Device> cuda(Context &Context, int Index = 0);

  /// Convenient function for creating SNPE device.
  /// \param Context runtime context.
  /// \return a \c Device that represents SNPE device.
  static Result<Device> snpe(Context &Context, bool FallbackToCPU = false);

  /// Convenient function for XNNPACK device.
  /// \param Context runtime context.
  /// \return a \c Device that represents XNNPACK device.
  static Result<Device> xnnpack(Context &Context);

  /// Convenient function for creating remote Native device.
  /// \param Context runtime context.
  /// \param Mode execution mode for CPU device.
  ///             Allowed values: PERFORMANCE, INTERMEDIATE, EFFICIENCY
  /// \return a \c Device that represents Native device.
  static Result<Device> native(RemoteContext &Context,
                               std::string_view Mode = "");

  /// Convenient function for creating remote Vulkan device.
  /// \param Context runtime context.
  /// \param Index index of device to select.
  /// \return a \c Device that represents Vulkan device.
  static Result<Device> vulkan(RemoteContext &Context, int Index = 0);

  /// Convenient function for creating remote OpenCL device.
  /// \param Context runtime context.
  /// \param Index index of device to select.
  /// \return a \c Device that represents OpenCL device.
  static Result<Device> opencl(RemoteContext &Context, int Index = 0);

  /// Convenient function for creating remote CUDA device.
  /// \param Context runtime context.
  /// \param Index index of device to select.
  /// \return a \c Device that represents CUDA device.
  static Result<Device> cuda(RemoteContext &Context, int Index = 0);

  /// Convenient function for creating remote SNPE device.
  /// \param Context runtime context.
  /// \return a \c Device that represents SNPE device.
  static Result<Device> snpe(RemoteContext &Context,
                             bool FallbackToCPU = false);

  /// Convenient function for creating remote XNNPACK device.
  /// \param Context runtime context.
  /// \return a \c Device that represents XNNPACK device.
  static Result<Device> xnnpack(RemoteContext &Context);

private:
  DeviceID ID = kInvalidDevice;
  Session *Owner = nullptr;
  Dict Options;
}; // end class Device
} // end namespace optimium::runtime

#endif // OPTIMIUM_RUNTIME_DEVICE_H