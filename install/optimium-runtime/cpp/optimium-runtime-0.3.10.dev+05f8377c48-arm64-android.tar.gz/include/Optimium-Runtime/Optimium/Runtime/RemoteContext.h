//===-- RemoteContext.h - Context of remote host ----------------*- C++ -*-===//
//
// This file is part of Optimium-Runtime. Confidential and proprietary.
//
// Copyright (c) 2022~2023 ENERZAi Corporation.
// All Rights Reserved.
//
//===----------------------------------------------------------------------===//
///
/// \file
/// This file contains declaration of \c RemoteContext class which represents
/// \c Context of remote host.
///
//===----------------------------------------------------------------------===//
#ifndef OPTIMIUM_RUNTIME_REMOTECONTEXT_H
#define OPTIMIUM_RUNTIME_REMOTECONTEXT_H

#include "Optimium/Runtime/Export.h"
#include "Optimium/Runtime/Forward.h"
#include "Optimium/Runtime/Utils/Any.h"
#include "Optimium/Runtime/Utils/NonCopyable.h"

#include <memory>
#include <vector>

namespace optimium::runtime {
class Session;

class OPTIMIUM_RT_API RemoteContext final {
public:
  OPTIMIUM_RT_NON_COPYABLE(RemoteContext)
  OPTIMIUM_RT_DEFAULT_MOVABLE(RemoteContext)

  RemoteContext() = default;

  /// Get a device from remote.
  /// \param Platform
  /// \param Kind
  /// \param Index
  /// \param RequiredCapability pointer of \c Capability which express required
  ///                           capability of the device.
  /// \return a \c Device that capable for given requirements.
  /// \note There are convenience wrappers also defined in \c Device class.
  /// \see optimium::runtime::Device
  Result<Device> getDevice(PlatformKind Platform, DeviceKind Kind,
                           int Index = 0,
                           const Capability *RequiredCapability = nullptr);

  /// Internal API.
  Result<Device> getDevice(DeviceID ID);

  /// Load a extension from given path.
  /// \param Path a path of a extension to load.
  Result<void> loadExtension(const std::string &Path);

  /// Get a list of information of devices that are currently recognized and
  /// accessible from the runtime.
  /// \return a \c std::vector that contains \c DeviceInfo represents
  /// information of recognized devices.
  [[nodiscard]] std::vector<Device> getAvailableDevices();

  /// Get remote host information.
  /// \return
  [[nodiscard]] const HostInfo &getHostInfo() const;

private:
  friend class Context;

  explicit RemoteContext(Session *Sess) : Sess(Sess) {}

  Session *Sess = nullptr;
}; // end class RemoteContext
} // end namespace optimium::runtime

#endif // OPTIMIUM_RUNTIME_REMOTECONTEXT_H