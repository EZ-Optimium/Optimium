//===-- Profile.h - Data for performance profiling --------------*- C++ -*-===//
//
// This file is part of Optimium-Runtime. Confidential and proprietary.
//
// Copyright (c) 2022~2023 ENERZAi Corporation.
// All Rights Reserved.
//
//===----------------------------------------------------------------------===//
///
/// \file
/// This file contains definitions of enums and structs related with profiling.
///
//===----------------------------------------------------------------------===//
#ifndef OPTIMIUM_RUNTIME_PROFILE_H
#define OPTIMIUM_RUNTIME_PROFILE_H

#include "Optimium/Runtime/Export.h"

#include <chrono>
#include <string>
#include <string_view>
#include <utility>
#include <variant>

namespace optimium::runtime {
enum class PlatformKind;

// clang-format off
#define OPTIMIUM_RT_PROFILE_KIND_ENUM(Op) \
  Op(ModelInit) \
  Op(RequestInit) \
  Op(TransferFromInput) \
  Op(TransferToOutput) \
  Op(RemoteTransfer) \
  Op(LayerExecute) \
  Op(Wait) \
  Op(BufferCopy) \
  Op(ModelExecute)
// clang-format on

/// Represents kind of profile data.
enum class ProfileKind {
/// \var ProfileKind::ModelInit
///      Represents taken time for initializing the model.
/// \var ProfileKind::RequestInit
///      Represents taken time for initializing the request.
/// \var ProfileKind::TransferFromInput
///      Represents taken time for coping from the host to the device for
///      input.
/// \var ProfileKind::TransferToOutput
///      Represents taken time for coping from the device to the host for
///      output.
/// \var ProfileKind::RemoteTransfer
///      Represents taken time for sending data back and forth between
///      host and remote device.
/// \var ProfileKind::LayerExecute
///      Represents taken time for executing the kernel.
/// \var ProfileKind::Wait
///      Represents taken time for waiting dependencies of the kernel.
/// \var ProfileKind::BufferCopy
///      Represents taken time for coping between buffers.
/// \var ProfileKind::ModelExecute
///      Represents total time for executing model.

#define OP(Value) Value,
  OPTIMIUM_RT_PROFILE_KIND_ENUM(OP)
#undef OP
      Last = ModelExecute
}; // end enum ProfileKind

/// Convert \c ProfileKind to readable string.
/// \param Value value for convert to string.
/// \return a string that represents corresponding \c ProfileKind.
OPTIMIUM_RT_API std::string_view toString(ProfileKind Value);

/// Represents measured profile data.
struct ProfileData {
  /// Kind of the data.
  ProfileKind Kind;

  struct LayerExecute {
    PlatformKind Platform;
    std::string Layer;
    std::string Device;
  }; // end struct LayerExecute

  struct BufferCopy {
    std::string Tensor;
    std::string FromDevice;
    std::string ToDevice;
  }; // end struct BufferCopy

  std::variant<std::string, LayerExecute, BufferCopy> Data;

  /// Taken time to do something.
  std::chrono::microseconds Time;

  ProfileData(ProfileKind Kind, std::string Name,
              std::chrono::microseconds Time)
      : Kind(Kind), Data(std::move(Name)), Time(Time) {}

  ProfileData(PlatformKind Platform, std::string Layer, std::string Device,
              std::chrono::microseconds Time)
      : Kind(ProfileKind::LayerExecute),
        Data(LayerExecute{Platform, std::move(Layer), std::move(Device)}),
        Time(Time) {}

  ProfileData(std::string Tensor, std::string From, std::string To,
              std::chrono::microseconds Time)
      : Kind(ProfileKind::BufferCopy),
        Data(BufferCopy{std::move(Tensor), std::move(From), std::move(To)}),
        Time(Time) {}

  [[nodiscard]] OPTIMIUM_RT_API std::string toString() const;
}; // end struct ProfileData
} // end namespace optimium::runtime

#endif // OPTIMIUM_RUNTIME_PROFILE_H