//===-- Tensor.h - Tensor of the model --------------------------*- C++ -*-===//
//
// This file is part of Optimium-Runtime. Confidential and proprietary.
//
// Copyright (c) 2022~2023 ENERZAi Corporation.
// All Rights Reserved.
//
//===----------------------------------------------------------------------===//
///
/// \file This file contains definition of \c Tensor class.
///
//===----------------------------------------------------------------------===//
#ifndef OPTIMIUM_RUNTIME_TENSOR_H
#define OPTIMIUM_RUNTIME_TENSOR_H

#include "Optimium/Runtime/Assert.h"
#include "Optimium/Runtime/Export.h"
#include "Optimium/Runtime/Result.h"
#include "Optimium/Runtime/TensorInfo.h"
#include "Optimium/Runtime/Utils/NonCopyable.h"

#include <iosfwd>

namespace optimium::runtime {
class SessionTensor;
class Tensor;

/// Represents raw buffer of the tensor.
///
/// \c BufferHolder gets device memory, which represents actual memory
/// representing a tensor, and holds it while the user accesses it. When
/// \c BufferHolder leaves its scope, it automatically releases the device
/// device memory so the device can access its own memory.
/// Due to its behavior, this object forbids coping and moving.
class OPTIMIUM_RT_API BufferHolder final {
  friend class Tensor;

public:
  OPTIMIUM_RT_NON_COPYABLE(BufferHolder)
  OPTIMIUM_RT_NON_MOVABLE(BufferHolder)

  ~BufferHolder() { release(); }

  /// Get raw pointer of the tensor memory.
  /// \return a raw pointer to memory.
  /// \warning This function does not verify whether the user accesses memory
  ///          outside of bounds. If you just want to copy data from/to the
  ///          tensor, use \c Tensor::copyFrom or \c Tensor::copyTo.
  void *data() const;

  /// Get raw pointer of the tensor memory with type cast.
  /// \tparam T type to fromJavaMap.
  /// \return raw pointer of the tensor memory in type \c T.
  /// \warning This function does not verify whether the user accesses memory
  ///          outside of bounds. If you just want to copy data from/to the
  ///          tensor, use \c Tensor::copyFrom or \c Tensor::copyTo.
  /// \warning This function does not verify whether given type is same as or
  ///          convertible to the actual type of the tensor. Use with caution.
  template <typename T>
  T *cast() {
    return reinterpret_cast<T *>(data());
  }

  /// Copy raw data from host memory to device memory.
  /// \param Source host memory that contains source data.
  /// \param Count size of buffer in bytes.
  /// \param Offset offset of device memory in bytes.
  Result<void> copyFrom(const void *Source, size_t Count,
                        size_t Offset = 0) const;

  /// Copy raw data from device memory to host memory.
  /// \param Dest host memory to store data.
  /// \param Count size of buffer in bytes.
  /// \param Offset offset of device memory in bytes.
  Result<void> copyTo(void *Dest, size_t Count, size_t Offset = 0) const;

private:
  explicit BufferHolder(SessionTensor &Ref) : Ref(Ref) {}

  void release() const;

  SessionTensor &Ref;
}; // end class BufferHolder

/// Represents a tensor of the model.
class OPTIMIUM_RT_API Tensor final {
public:
  OPTIMIUM_RT_NON_COPYABLE(Tensor)
  OPTIMIUM_RT_DEFAULT_MOVABLE(Tensor)

  Tensor() = default;

  /// Get raw buffer of the tensor.
  /// \return a \c BufferHolder object that represents raw buffer of the tensor.
  [[nodiscard]] BufferHolder getRawBuffer() const {
    NEVER_BE_NULL(Detail);
    return BufferHolder(*Detail);
  }

  /// Copy tensor contents from typed buffer.
  /// \tparam T type of the buffer.
  /// \param Source host memory that contains source data.
  /// \param Count count of elements to copy.
  /// \param Offset offset of the tensor.
  template <typename T>
  Result<void> copyFrom(const T *Source, size_t Count, size_t Offset = 0) {
    CHECK(checkType(getTypeFromPrimitive<T>()));
    return copyFrom(reinterpret_cast<const void *>(Source), Count, Offset,
                    sizeof(T));
  }

  Result<void> copyFrom(std::istream &Input) {
    return Error(Status::NotImplemented, "not implemented.");
  }

  template <typename IteratorT>
  Result<void> copyFrom(IteratorT Begin, IteratorT End, size_t Offset = 0) {
    // TODO: Implement
    return Error(Status::NotImplemented, "not implemented");
  }

  /// Copy tensor contents to typed buffer.
  /// \tparam T type of the buffer.
  /// \param Dest host memory to store data.
  /// \param Count count of elements to copy.
  /// \param Offset offset of the tensor.
  template <typename T>
  Result<void> copyTo(T *Dest, size_t Count, size_t Offset = 0) {
    CHECK(checkType(getTypeFromPrimitive<T>()));
    return copyTo(reinterpret_cast<void *>(Dest), Count, Offset, sizeof(T));
  }

  Result<void> copyTo(std::ostream &Output) {
    return Error(Status::NotImplemented, "not implemented.");
  }

  template <typename IteratorT>
  Result<void> copyTo(IteratorT Begin, IteratorT End, size_t Offset = 0) {
    // TODO: Implement
    return Error(Status::NotImplemented, "not implemented");
  }

  /// Fill tensor as scalar value.
  /// \tparam T type of scalar value.
  /// \param Value value to fill the tensor.
  template <typename T>
  Result<void> fill(T Value) {
    CHECK(checkType(getTypeFromPrimitive<T>()));

    auto Buffer = getRawBuffer();
    T *Ptr = Buffer.cast<T>();
    if (Ptr == nullptr)
      return Error(Status::OutOfResource, "Buffer is null");

    auto Size = getShape().getTotalElementCount();
    std::fill_n(Ptr, Size, Value);
    return Ok();
  }

  /// TODO: Add subview supports

  /// Get name of the tensor.
  /// \return a string that represents name of the tensor.
  [[nodiscard]] const std::string &getName() const { return Info->TensorName; }

  /// Get shape of the tensor.
  /// \return \c Shape that represents shape of the tensor.
  [[nodiscard]] const Shape &getShape() const { return Info->TensorShape; }

  /// Get type of the tensor.
  /// \return an \c ElementType that represents type of the tensor.
  [[nodiscard]] ElementType getType() const { return Info->TensorType; }

  /// Get size of the tensor.
  /// \return an integral value that represents size of the tensor in bytes.
  [[nodiscard]] size_t getTensorSize() const {
    return ::optimium::runtime::getTensorSize(*Info);
  }

  /// Convert \c Tensor to readable string.
  /// \return a string that represents corresponding \c Tensor.
  [[nodiscard]] OPTIMIUM_RT_API std::string toString() const;

private:
  friend class InferRequest;
  friend struct SessionTensor;

  SessionTensor *Detail = nullptr;
  const TensorInfo *Info = nullptr;

  Tensor(SessionTensor *Detail, const TensorInfo &Info)
      : Detail(Detail), Info(&Info) {}

  Result<void> copyFrom(const void *, size_t, size_t, size_t);
  Result<void> copyTo(void *, size_t, size_t, size_t);
  Result<void> checkType(ElementType);
}; // end class Tensor
} // end namespace optimium::runtime

#endif // OPTIMIUM_RUNTIME_TENSOR_H