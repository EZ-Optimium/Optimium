//===-- Capability.h - Capability of the device -----------------*- C++ -*-===//
//
// This file is part of Optimium-Runtime. Confidential and proprietary.
//
// Copyright (c) 2022~2023 ENERZAi Corporation.
// All Rights Reserved.
//
//===----------------------------------------------------------------------===//
///
/// \file
/// This file contains declarations of structs that describes "capabilities" of
/// each devices.
///
//===----------------------------------------------------------------------===//
#ifndef OPTIMIUM_RUNTIME_CAPABILITY_H
#define OPTIMIUM_RUNTIME_CAPABILITY_H

#include "Optimium/Runtime/Export.h"
#include "Optimium/Runtime/Utils/EnumFlags.h"

#include <cassert>
#include <string>
#include <string_view>
#include <tuple>
#include <type_traits>
#include <utility>

namespace optimium::runtime {
enum class CapabilityKind { Void, X86, ARM, SPIRV, CUDA };

class VoidCapability;

/// Base class of classes that describe "capabilities" of the device.
struct OPTIMIUM_RT_API Capability {
protected:
  explicit Capability(CapabilityKind Kind) : Kind(Kind) {}

public:
  const CapabilityKind Kind;

  /// Test the object is \c CapabilityT.
  /// \tparam CapabilityT
  /// \return
  template <typename CapabilityT>
  [[nodiscard]] bool is() const {
    static_assert(std::is_base_of_v<Capability, CapabilityT>,
                  "CapabilityT should be derived from Capability.");

    return CapabilityT::getKind() == Kind;
  }

  /// Cast the object to \c CapabilityT.
  /// \tparam CapabilityT destination type to cast_raw.
  /// \return a reference of self in \c CapabilityT.
  /// \throw std::bad_cast thrown when the object is not \c CapabilityT.
  template <typename CapabilityT>
  CapabilityT &as() {
    assert(is<CapabilityT>() && "cannot cast_raw to CapabilityT");
    return *static_cast<CapabilityT *>(this);
  }

  /// Cast the object to \c CapabilityT.
  /// \tparam CapabilityT destination type to cast_raw.
  /// \return a const reference of self in \c CapabilityT.
  /// \throw std::bad_cast thrown when the object is not \c CapabilityT.
  template <typename CapabilityT>
  const CapabilityT &as() const {
    assert(is<CapabilityT>() && "cannot cast_raw to CapabilityT");
    return *static_cast<const CapabilityT *>(this);
  }

  /// Convert \c Capability to readable string.
  /// \return a string that represents corresponding \c Capability.
  [[nodiscard]] std::string toString() const;

  /// Test this capability is capable for \c Other.
  /// \param Other base capability to be compared.
  /// \return \c true if the capability is capable, otherwise \c false.
  [[nodiscard]] bool isCapable(const Capability &Other) const {
    return isCapable(*this, Other);
  }

  /// Test \c This capability is capable for \c That capability.
  /// \param This target capability to compare.
  /// \param That base capability to be compared.
  /// \return \c true if the capability is capable, otherwise \c false.
  static bool isCapable(const Capability &This, const Capability &That);

  static Capability *getVoid();
}; // end class Capability

struct VoidCapability final : public Capability {
private:
  friend class Capability;

  VoidCapability() : Capability(CapabilityKind::Void) {}

public:
  static constexpr CapabilityKind getKind() { return CapabilityKind::Void; }
}; // end class VoidCapability

// clang-format off
#define OPTIMIUM_RT_X86_FEATURE_KIND_ENUM(Op) \
  Op(MMX) \
  Op(SSE) \
  Op(SSE2) \
  Op(SSE3) \
  Op(SSSE3) \
  Op(SSE4a) \
  Op(SSE41) \
  Op(SSE42) \
  Op(AVX) \
  Op(F16C) \
  Op(FMA) \
  Op(AVX_VNNI) \
  Op(AVX2) \
  Op(AVX512_4FMAPS) \
  Op(AVX512_4VNNIW) \
  Op(AVX512_BF16) \
  Op(AVX512_BW) \
  Op(AVX512_CD) \
  Op(AVX512_DQ) \
  Op(AVX512_ER) \
  Op(AVX512_F) \
  Op(AVX512_FP16) \
  Op(AVX512_IFMA) \
  Op(AVX512_PF) \
  Op(AVX512_VBMI) \
  Op(AVX512_VBMI2) \
  Op(AVX512_VL) \
  Op(AVX512_VNNI) \
  Op(AMX_BF16) \
  Op(AMX_FP16) \
  Op(AMX_IFMA) \
  Op(AMX_INT8) \
  Op(AMX_TILE)
// clang-format on

/// Represent features that x86 series CPUs.
enum class X86FeatureKind {
#define OP(Value) Value,
  OPTIMIUM_RT_X86_FEATURE_KIND_ENUM(OP)
#undef OP
      Last = AMX_TILE
}; // end enum X86FeatureKind

/// Convert \c X86FeatureKind to readable string.
/// \param Value value for convert to string.
/// \return a string that represents corresponding \c X86FeatureKind.
OPTIMIUM_RT_API std::string_view toString(X86FeatureKind Value);

/// Represents capability of x86 series CPUs.
struct X86Capability final : public Capability,
                             public EnumFlags<X86FeatureKind> {
public:
  using FlagsType = EnumFlags<X86FeatureKind>;

  X86Capability() : Capability(CapabilityKind::X86) {}

  /// L1 data cache size in bytes.
  uint64_t L1 = 0;

  /// L2 data cache size in bytes.
  uint64_t L2 = 0;

  /// L3 data cache size in bytes.
  uint64_t L3 = 0;

  static constexpr CapabilityKind getKind() { return CapabilityKind::X86; }
}; // end struct X86Capability

// clang-format off
#define OPTIMIUM_RT_ARM_FEATURE_KIND_ENUM(Op) \
  Op(FP) \
  Op(FP16) \
  Op(FP64) \
  Op(Neon) \
  Op(NeonFP16) \
  Op(SVE) \
  Op(SVE2) \
  Op(SME) \
  Op(BF16) \
  Op(NeonBF16) \
  Op(FP16FML) \
  Op(F32MM) \
  Op(F64MM) \
  Op(DotProd) \
  Op(I8MM)
// clang-format on

/// Represent features that ARM series CPUs.
enum class ARMFeatureKind {
#define OP(Value) Value,
  OPTIMIUM_RT_ARM_FEATURE_KIND_ENUM(OP)
#undef OP
      Last = I8MM
}; // end enum ARMFeatureKind

/// Convert \c ARMFeatureKind to readable string.
/// \param Value value for convert to string.
/// \return a string that represents corresponding \c ARMFeatureKind.
OPTIMIUM_RT_API std::string_view toString(ARMFeatureKind Value);

/// Represents capability of ARM series CPUs.
struct ARMCapability final : public Capability,
                             public EnumFlags<ARMFeatureKind, uint32_t> {
  using FlagsType = EnumFlags<ARMFeatureKind, uint32_t>;

  ARMCapability() : Capability(CapabilityKind::ARM) {}

  /// L1 data cache size in bytes.
  uint64_t L1 = 0;

  /// L2 data cache size in bytes.
  uint64_t L2 = 0;

  /// L3 data cache size in bytes.
  uint64_t L3 = 0;

  static constexpr CapabilityKind getKind() { return CapabilityKind::ARM; }
}; // end struct ARMCapability

// clang-format off
#define OPTIMIUM_RT_SPIRV_FEATURE_KIND_ENUM(Op) \
  Op(Int8) \
  Op(Int16) \
  Op(Int64) \
  Op(Float16) \
  Op(Float64) \
  Op(StorageBuffer) \
  Op(Int64Atomics) \
  Op(Float16Atomics) \
  Op(Float16ExtendedAtomics) \
  Op(Float32Atomics) \
  Op(Float32ExtendedAtomics) \
  Op(Float64Atomics) \
  Op(Float64ExtendedAtomics) \
  Op(StorageBuffer16BitAccess) \
  Op(UniformBuffer16BitAccess) \
  Op(PushConstant16Bit) \
  Op(InputOutput16Bit) \
  Op(StorageBuffer8BitAccess) \
  Op(UniformBuffer8BitAccess) \
  Op(PushConstant8Bit) \
  Op(VariablePointers) \
  Op(VariablePointersStorageBuffer) \
  Op(IntegerDotProduct) \
  Op(Float16DenormPreserve) \
  Op(Float16DenormFlushToZero) \
  Op(Float16SignedZeroInfNaNPreserve) \
  Op(Float16RoundModeRTE) \
  Op(Float16RoundModeRTZ) \
  Op(Float32DenormPreserve) \
  Op(Float32DenormFlushToZero) \
  Op(Float32SignedZeroInfNaNPreserve) \
  Op(Float32RoundModeRTE) \
  Op(Float32RoundModeRTZ) \
  Op(Float64DenormPreserve) \
  Op(Float64DenormFlushToZero) \
  Op(Float64SignedZeroInfNaNPreserve) \
  Op(Float64RoundModeRTE) \
  Op(Float64RoundModeRTZ)
// clang-format on

/// Represent features of the device that runs SPIR-V binary.
enum class SPIRVFeatureKind {
#define OP(Value) Value,
  OPTIMIUM_RT_SPIRV_FEATURE_KIND_ENUM(OP)
#undef OP
      Last = Float64RoundModeRTZ
}; // end enum SPIRVFeatureKind

/// Convert \c SPIRVFeatureKind to readable string.
/// \param Value value for convert to string.
/// \return a string that represents corresponding \c SPIRVFeatureKind.
OPTIMIUM_RT_API std::string_view toString(SPIRVFeatureKind Value);

// clang-format off
#define OPTIMIUM_RT_SPIRV_TARGET_ENUM(Op) \
  Op(Kernel32) \
  Op(Kernel64) \
  Op(GLCompute)
// clang-format on

/// Represent target environment that SPIR-V binary is executed.
/// This also implies memory model of SPIR-V binary.
enum class SPIRVTarget {
#define OP(Value) Value,
  OPTIMIUM_RT_SPIRV_TARGET_ENUM(OP)
#undef OP
      Last = GLCompute
}; // end enum SPIRVTarget

/// Convert \c SPIRVTarget to readable string.
/// \param Value value for convert to string.
/// \return a string that represents corresponding \c SPIRVTarget.
OPTIMIUM_RT_API std::string_view toString(SPIRVTarget Value);

using Dim3 = std::tuple<uint32_t, uint32_t, uint32_t>;

/// Represents capability of the device that runs SPIR-V binary.
struct SPIRVCapability final : public Capability,
                               public EnumFlags<SPIRVFeatureKind> {
  using FlagsType = EnumFlags<SPIRVFeatureKind>;

  SPIRVCapability() : Capability(CapabilityKind::SPIRV) {}

  /// Target environment of the device.
  SPIRVTarget Target = SPIRVTarget::GLCompute;

  /// Version of library / framework that supports SPIR-V.
  /// Its representation may differ between extensions.
  uint32_t TargetVersion = 0;

  /// Version of SPIR-V.
  uint32_t SPIRVVersion = 0;

  /// Maximum grid(workgroup) size.
  Dim3 MaxGridSize = Dim3();

  /// Maximum elements in grid(workgroup).
  uint32_t MaxGridCount = 0;

  /// Maximum block(local workgroup) size.
  Dim3 MaxBlockSize = Dim3();

  /// Maximum elements in block(local workgroup)
  uint32_t MaxBlockCount = 0;

  /// Maximum shared memory size in byte_.
  uint64_t MaxSharedMemorySize = 0;

  /// Maximum constant memory size in byte_.
  uint64_t MaxConstMemorySize = 0;

  static constexpr CapabilityKind getKind() { return CapabilityKind::SPIRV; }
}; // end struct SPIRVCapability

/// Represents capability of CUDA device.
struct CUDACapability final : public Capability {
  CUDACapability() : Capability(CapabilityKind::CUDA) {}

  /// Compute capability of CUDA device.
  /// \see
  /// https://docs.nvidia.com/cuda/cuda-c-programming-guide/index.html#compute-capabilities
  uint32_t ComputeCapability = 0;

  static constexpr CapabilityKind getKind() { return CapabilityKind::CUDA; }
}; // end struct CUDACapability
} // end namespace optimium::runtime

#endif // OPTIMIUM_RUNTIME_CAPABILITY_H