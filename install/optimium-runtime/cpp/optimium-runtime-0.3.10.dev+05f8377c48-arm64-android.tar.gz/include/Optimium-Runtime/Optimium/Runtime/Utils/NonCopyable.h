//===-- NonCopyable.h - Make class non-copyable -----------------*- C++ -*-===//
//
// This file is part of Optimium-Runtime. Confidential and proprietary.
//
// Copyright (c) 2022~2023 ENERZAi Corporation.
// All Rights Reserved.
//
//===----------------------------------------------------------------------===//
///
/// \file
/// This file contains macros for making class non-copyable and/or non-movable.
///
//===----------------------------------------------------------------------===//
#ifndef OPTIMIUM_RUNTIME_UTILS_NON_COPYABLE_H
#define OPTIMIUM_RUNTIME_UTILS_NON_COPYABLE_H

#define OPTIMIUM_RT_NON_COPYABLE(Class)                                        \
  Class(const Class &) = delete;                                               \
  Class &operator=(const Class &) = delete;

#define OPTIMIUM_RT_NON_MOVABLE(Class)                                         \
  Class(Class &&) = delete;                                                    \
  Class &operator=(Class &&) = delete;

#define OPTIMIUM_RT_DEFAULT_COPYABLE(Class)                                    \
  Class(const Class &) = default;                                              \
  Class &operator=(const Class &) = default;

#define OPTIMIUM_RT_DEFAULT_MOVABLE(Class)                                     \
  Class(Class &&) noexcept = default;                                          \
  Class &operator=(Class &&) noexcept = default;

#define OPTIMIUM_RT_STATIC_CLASS(Class)                                        \
  Class() = delete;                                                            \
  ~Class() = delete;                                                           \
  OPTIMIUM_RT_NON_COPYABLE(Class)                                              \
  OPTIMIUM_RT_NON_MOVABLE(Class)

#endif // OPTIMIUM_RUNTIME_UTILS_NON_COPYABLE_H